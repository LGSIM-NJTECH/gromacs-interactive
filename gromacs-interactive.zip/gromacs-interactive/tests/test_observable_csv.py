import csv
import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
import uuid

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from observable_csv import rmsf_stem, export, read_xvg


class ObservableTests(unittest.TestCase):
    def setUp(self):
        self.parent=Path(os.environ.get('GMX_TEST_TMP',tempfile.gettempdir())).resolve()
        self.root=self.parent/('observable-test-'+uuid.uuid4().hex)
        self.root.mkdir(mode=0o777)
        self.addCleanup(self.cleanup)

    def cleanup(self):
        if self.root.resolve().parent!=self.parent: raise RuntimeError('Unexpected cleanup directory')
        shutil.rmtree(self.root)

    def source(self,name,body,x='Residue',unit='(nm)'):
        p=self.root/name;p.write_text(f'@ xaxis label "{x}"\n@ yaxis label "{unit}"\n@TYPE xy\n'+body,encoding='utf-8');return p

    def test_duration_is_segment_length_not_endpoint(self):
        self.assertEqual(rmsf_stem(50000,100000),'rmsf_50ns')
        self.assertEqual(rmsf_stem(80000,100000),'rmsf_20ns')
        self.assertEqual(rmsf_stem('1000','3500'),'rmsf_2.5ns')
        self.assertEqual(rmsf_stem(0,0.5),'rmsf_0.0005ns')

    def test_invalid_windows(self):
        for a,b in [(0,0),(2,1),(-1,2),(0,'NaN')]:
            with self.assertRaises(ValueError):rmsf_stem(a,b)

    def test_rmsf_keeps_residue_ids_and_original_values(self):
        p=self.source('rmsf_2ns.xvg','10 0.1\n11 0.2\n');before=p.read_bytes()
        out=self.root/'rmsf_2ns.csv';export(p,out,'rmsf',0,2000)
        with out.open(encoding='utf-8-sig') as f:rows=list(csv.DictReader(f))
        self.assertEqual(rows[0],{'residue_number':'10','rmsf_nm':'0.1'})
        self.assertEqual(p.read_bytes(),before)

    def test_wrong_duration_name_rejected(self):
        p=self.source('rmsf_20ns.xvg','1 0.1\n2 0.2\n')
        with self.assertRaisesRegex(ValueError,'时长不符'):export(p,self.root/'rmsf_20ns.csv','rmsf',0,2000)

    def test_duplicate_residues_rejected(self):
        p=self.source('rmsf_2ns.xvg','1 0.1\n1 0.2\n')
        with self.assertRaisesRegex(ValueError,'重复'):read_xvg(p,'rmsf')

    def test_rg_columns_and_time_conversion(self):
        p=self.source('rg.xvg','1000 2 1.6 1.7 1.8\n2000 3 2.6 2.7 2.8\n',x='Time (ps)')
        out=self.root/'rg.csv';export(p,out,'rg',1000,2000)
        with out.open(encoding='utf-8-sig') as f:rows=list(csv.DictReader(f))
        self.assertEqual(rows[0],{'time_ns':'1.0','rg_nm':'2.0','rg_x_nm':'1.6','rg_y_nm':'1.7','rg_z_nm':'1.8'})

    def test_rg_missing_direction_column_rejected(self):
        p=self.source('rg.xvg','0 2\n20 2.1\n',x='Time (ps)')
        with self.assertRaisesRegex(ValueError,'列数'):read_xvg(p,'rg')

    def test_units_not_guessed(self):
        p=self.source('rg.xvg','0 2 1 1 1\n2 2 1 1 1\n',x='Time (ns)')
        with self.assertRaisesRegex(ValueError,'ps 横轴'):read_xvg(p,'rg')

    def test_nonfinite_value_rejected(self):
        p=self.source('rmsf_2ns.xvg','1 NaN\n2 0.2\n')
        with self.assertRaisesRegex(ValueError,'NaN'):read_xvg(p,'rmsf')

    def test_existing_csv_not_overwritten(self):
        p=self.source('rmsf_2ns.xvg','1 0.1\n2 0.2\n');out=self.root/'rmsf_2ns.csv'
        out.write_text('keep')
        with self.assertRaisesRegex(ValueError,'已存在'):export(p,out,'rmsf',0,2000)
        self.assertEqual(out.read_text(),'keep')


if __name__=='__main__':unittest.main()
