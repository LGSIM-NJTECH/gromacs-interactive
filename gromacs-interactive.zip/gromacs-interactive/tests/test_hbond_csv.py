import csv
import json
from pathlib import Path
import sys
import tempfile
import unittest
import uuid
import os
import shutil
from contextlib import contextmanager

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from hbond_csv import export


@contextmanager
def test_directory():
    parent = Path(os.environ.get('GMX_TEST_TMP', tempfile.gettempdir())).resolve()
    root = parent / ('hbond-test-' + uuid.uuid4().hex)
    root.mkdir(mode=0o777)
    try:
        yield root
    finally:
        if root.resolve().parent != parent:
            raise RuntimeError('Unexpected cleanup directory')
        shutil.rmtree(root)


class HbondCsvTests(unittest.TestCase):
    def run_export(self, data):
        with test_directory() as folder:
            root = Path(folder)
            source = root / 'hbnum.xvg'
            source.write_text(data, encoding='utf-8')
            report = export(source, root / 'hbnum.csv')
            with (root / 'hbnum.csv').open(newline='') as stream:
                rows = list(csv.reader(stream))
            return report, rows

    def test_preserves_all_frames_and_selects_hbond_not_distance_pairs(self):
        report, rows = self.run_export('@ xaxis label "Time (ps)"\n@ s0 legend "Pairs within 0.35 nm"\n@ s1 legend "Hydrogen bonds"\n0 9 1\n20 8 0\n40 7 2\n')
        self.assertEqual(rows, [['time_ns', 'hbond_count'], ['0.0', '1'], ['0.02', '0'], ['0.04', '2']])
        self.assertEqual(report['framewise_mean'], 1)
        self.assertEqual(report['selected_numeric_column_1based'], 3)

    def test_all_zero_is_valid_and_ns_is_not_converted_twice(self):
        report, rows = self.run_export('@ xaxis label "Time (ns)"\n@ s0 legend "Hydrogen bonds"\n0 0\n0.02 0\n')
        self.assertEqual(report['time_ns'], [0, 0.02])
        self.assertEqual(report['fraction_of_sampled_frames_with_any_hbond'], 0)

    def test_rejects_invalid_counts_and_ambiguous_legend(self):
        for bad in ('-1', '0.5', 'nan'):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                self.run_export('@ xaxis label "Time (ps)"\n@ s0 legend "Hydrogen bonds"\n0 1\n20 '+bad+'\n')
        with self.assertRaisesRegex(ValueError, '唯一识别'):
            self.run_export('@ xaxis label "Time (ps)"\n0 1\n20 2\n')

    def test_rejects_duplicate_times(self):
        with self.assertRaisesRegex(ValueError, '严格递增'):
            self.run_export('@ xaxis label "Time (ps)"\n@ s0 legend "Hydrogen bonds"\n0 1\n0 2\n')


if __name__ == '__main__':
    unittest.main()
