import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
import uuid

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from saltbridge_csv import summarize
from origin_saltbridge import load_job


class SaltbridgeTests(unittest.TestCase):
    def setUp(self):
        self.parent=Path(os.environ.get('GMX_TEST_TMP',tempfile.gettempdir())).resolve()
        self.root=self.parent/('saltbridge-test-'+uuid.uuid4().hex)
        self.root.mkdir(mode=0o777)
        self.addCleanup(self.cleanup)
        (self.root/'vmd-check.txt').write_text('status=PASSED\ntrajectory_frames=3\ncutoff_A=3.2\nnative_pairs=1\n')
        (self.root/'pairs.tsv').write_text('pair_id\tacid_residue_index\tacid_resid\tacid_resname\tacid_chain\tacid_segname\tbase_residue_index\tbase_resid\tbase_resname\tbase_chain\tbase_segname\nr1_r2\t1\t2\tASP\tA\t\t2\t3\tLYS\tA\t\n')
        self.frames=self.root/'frames.csv'
        self.frames.write_text('sample_index,vmd_frame,time_ps,pair_id,min_on_A,present\n0,1,0,r1_r2,2.8,1\n1,2,20,r1_r2,3.3,0\n2,3,40,r1_r2,3.0,1\n')

    def cleanup(self):
        if self.root.resolve().parent!=self.parent:raise RuntimeError('Unexpected cleanup path')
        shutil.rmtree(self.root)

    def test_full_frame_denominator_and_single_real_column(self):
        r=summarize(self.root,'Sample')
        self.assertEqual(r['frames'],3)
        with (self.root/'saltbridge.csv').open(newline='') as stream:rows=list(csv.reader(stream))
        self.assertEqual(rows,[['Salt bridge','Sample'],['A:ASP2-A:LYS3',str(2/3)]])

    def test_missing_observation_not_replaced_with_zero(self):
        self.frames.write_text(self.frames.read_text().replace('1,2,20,r1_r2,3.3,0\n',''))
        with self.assertRaisesRegex(ValueError,'Missing frames'):summarize(self.root,'Sample')

    def test_same_frame_cannot_be_counted_twice(self):
        self.frames.write_text(self.frames.read_text()+'0,1,0,r1_r2,2.8,1\n')
        with self.assertRaisesRegex(ValueError,'duplicate'):summarize(self.root,'Sample')

    def test_presence_distance_inconsistency_rejected(self):
        self.frames.write_text(self.frames.read_text().replace('3.3,0','4.0,1'))
        with self.assertRaisesRegex(ValueError,'inconsistent'):summarize(self.root,'Sample')

    def plot_job(self):
        summarize(self.root,'Sample')
        p=self.root/'saltbridge.csv'
        job={'csv':str(p),'csv_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
             'chart':'heatmap','chart_confirmed':True,'template_confirmed':True,'color_range':[0,1],'smooth':False}
        j=self.root/'plot.json';j.write_text(json.dumps(job));return j,p,job

    def test_heatmap_retains_one_system_and_real_values(self):
        j,p,job=self.plot_job()
        _,_,fields,rows,values=load_job(j)
        self.assertEqual(fields,['Salt bridge','Sample'])
        self.assertEqual(values,[[2/3]])

    def test_heatmap_rejects_missing_or_out_of_range_occupancy(self):
        j,p,job=self.plot_job()
        for bad in ('nan','1.1','-0.1'):
            p.write_text('Salt bridge,Sample\nA:ASP2-A:LYS3,'+bad+'\n')
            job['csv_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();j.write_text(json.dumps(job))
            with self.assertRaisesRegex(ValueError,'Occupancy'):load_job(j)


if __name__=='__main__':unittest.main()
