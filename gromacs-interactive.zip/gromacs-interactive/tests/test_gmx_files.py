import json
from pathlib import Path
import sys
import tempfile
import unittest
import os
import shutil
import uuid

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import gmx_files as tool


def write_gro(path,atoms):
    lines=['test',str(len(atoms))]
    for i,(resid,resname,name) in enumerate(atoms,1):
        lines.append(f'{resid:5d}{resname:<5}{name:>5}{i:5d}{i*0.01:8.3f}{0:8.3f}{0:8.3f}')
    path.write_text('\n'.join(lines)+'\n   3.00000   3.00000   3.00000\n',encoding='utf-8')


class TopologyTests(unittest.TestCase):
    def setUp(self):
        parent=Path(os.environ.get('GMX_TEST_TMP',tempfile.gettempdir())).resolve()
        self.root=parent/('gmx-test-'+uuid.uuid4().hex)
        self.root.mkdir(mode=0o777)
        def cleanup():
            if self.root.resolve().parent!=parent:
                raise ValueError('Unexpected test cleanup path')
            shutil.rmtree(self.root)
        self.addCleanup(cleanup)
        self.protein=[(1,'ALA','N'),(1,'ALA','CA'),(2,'GLY','N'),(2,'GLY','CA')]
        self.water=[(1,'SOL','OW'),(1,'SOL','HW1'),(1,'SOL','HW2')]
        write_gro(self.root/'protein.gro',self.protein)
        write_gro(self.root/'water.gro',self.water)
        write_gro(self.root/'ion.gro',[(1,'NA','NA')])
        self.mapping=self.root/'map.json'
        self.mapping.write_text(json.dumps({'templates':[
            {'name':'Protein_chain_A','gro':'protein.gro'},
            {'name':'WATER_TYPE','gro':'water.gro'},
            {'name':'NA','gro':'ion.gro'}]}),encoding='utf-8')
        self.coordinate=self.root/'actual.gro'
        self.atoms=self.protein+[(3,r,n) for _,r,n in self.water]+[(4,r,n) for _,r,n in self.water]+[(5,'NA','NA')]
        write_gro(self.coordinate,self.atoms)
        self.top=self.root/'topol.top'
        self.top.write_bytes(b'#include "forcefield.itp"\r\n[ system ]\r\nExample\r\n[ molecules ]\r\nProtein_chain_A 1\r\nWATER_TYPE 10\r\n')

    def make_proposal(self):
        result=tool.proposal(self.top,self.coordinate,self.mapping)
        path=self.root/'change.json'
        path.write_text(json.dumps(result),encoding='utf-8')
        return result,path

    def test_counts_multi_residue_protein_and_different_molecule_name(self):
        result,_=self.make_proposal()
        self.assertEqual(result['rows'],[['Protein_chain_A',1],['WATER_TYPE',2],['NA',1]])
        self.assertTrue(result['changed'])
        self.assertEqual(self.top.read_bytes().count(b'WATER_TYPE 10'),1)

    def test_apply_backup_and_second_proposal_noop(self):
        original=self.top.read_bytes()
        _,path=self.make_proposal()
        applied=tool.apply(path)
        self.assertEqual(Path(applied['backup']).read_bytes(),original)
        self.assertEqual(self.top.read_bytes().count(b'[ molecules ]'),1)
        self.assertIn(b'\r\n',self.top.read_bytes())
        result=tool.proposal(self.top,self.coordinate,self.mapping)
        self.assertFalse(result['changed'])
        path.write_text(json.dumps(result),encoding='utf-8')
        self.assertFalse(tool.apply(path)['changed'])

    def test_stale_coordinate_rejected_without_touching_top(self):
        original=self.top.read_bytes(); _,path=self.make_proposal()
        write_gro(self.coordinate,self.atoms[:-1])
        with self.assertRaisesRegex(ValueError,'已变更'): tool.apply(path)
        self.assertEqual(self.top.read_bytes(),original)

    def test_tampered_proposal_rejected(self):
        result,path=self.make_proposal(); result['replacement']='wrong'
        path.write_text(json.dumps(result),encoding='utf-8')
        with self.assertRaisesRegex(ValueError,'不一致'): tool.apply(path)

    def test_atom_reordering_rejected(self):
        altered=list(self.atoms); altered[4],altered[5]=altered[5],altered[4]
        write_gro(self.coordinate,altered)
        with self.assertRaisesRegex(ValueError,'拒绝猜测'): self.make_proposal()

    def test_ambiguous_templates_rejected(self):
        doc=json.loads(self.mapping.read_text())
        doc['templates'].append({'name':'OTHER_WATER','gro':'water.gro'})
        self.mapping.write_text(json.dumps(doc))
        with self.assertRaisesRegex(ValueError,'匹配 2'): self.make_proposal()

    def test_residue_boundary_mismatch_rejected(self):
        altered=list(self.atoms); altered[2]=(1,'GLY','N'); altered[3]=(1,'GLY','CA')
        # Resname change still marks a distinct residue; same resname plus changed
        # resid is the case where exact boundary matching matters.
        template=[(1,'ALA','N'),(1,'ALA','CA'),(2,'ALA','N'),(2,'ALA','CA')]
        write_gro(self.root/'protein.gro',template)
        altered[:4]=[(1,'ALA','N'),(1,'ALA','CA'),(1,'ALA','N'),(1,'ALA','CA')]
        write_gro(self.coordinate,altered)
        with self.assertRaisesRegex(ValueError,'拒绝猜测'): self.make_proposal()

    def test_preprocessor_and_extra_sections_rejected(self):
        for tail in ('#ifdef X\nWATER_TYPE 2\n#endif\n','[ atoms ]\n1 X\n'):
            with self.subTest(tail=tail):
                self.top.write_text('[ system ]\nX\n[ molecules ]\n'+tail)
                with self.assertRaises(ValueError): self.make_proposal()

    def test_changed_top_rejected(self):
        _,path=self.make_proposal()
        with self.top.open('a') as f:f.write('; external edit\n')
        with self.assertRaisesRegex(ValueError,'已变更'): tool.apply(path)

    def test_changed_template_rejected(self):
        original=self.top.read_bytes(); _,path=self.make_proposal()
        write_gro(self.root/'water.gro',[(1,'SOL','OH'),(1,'SOL','H1'),(1,'SOL','H2')])
        with self.assertRaisesRegex(ValueError,'已变更'): tool.apply(path)
        self.assertEqual(self.top.read_bytes(),original)

    def test_noncontiguous_molecule_runs_keep_order(self):
        write_gro(self.coordinate,self.protein+self.water+[(2,'NA','NA')]+self.water)
        rows,_=tool.molecule_rows(self.coordinate,self.mapping)
        self.assertEqual(rows,[['Protein_chain_A',1],['WATER_TYPE',1],['NA',1],['WATER_TYPE',1]])

    def test_inspect_is_readonly(self):
        before={str(p):p.read_bytes() for p in self.root.iterdir() if p.is_file()}
        result=tool.inventory(self.root)
        self.assertTrue(result['files'])
        after={str(p):p.read_bytes() for p in self.root.iterdir() if p.is_file()}
        self.assertEqual(before,after)


if __name__=='__main__':unittest.main()
