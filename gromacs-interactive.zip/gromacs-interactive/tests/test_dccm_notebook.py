import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
import uuid

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from prepare_dccm_notebook import prepare,source_digest


class DccmNotebookTests(unittest.TestCase):
    def setUp(self):
        self.parent=Path(os.environ.get('GMX_TEST_TMP',tempfile.gettempdir())).resolve()
        self.root=self.parent/('dccm-test-'+uuid.uuid4().hex)
        self.root.mkdir(mode=0o777)
        self.addCleanup(self.cleanup)

    def cleanup(self):
        if self.root.resolve().parent!=self.parent:raise RuntimeError('Unexpected cleanup path')
        shutil.rmtree(self.root)

    def test_portable_paths_including_space_and_no_execution(self):
        p=self.root/'new computer'/'DCCM'
        input_file=p/'results.dat'
        result=prepare(p,input_file)
        nb=json.loads((p/'DCCM.ipynb').read_text(encoding='utf-8'))
        code='\n'.join(''.join(c.get('source',[])) for c in nb['cells'])
        self.assertIn(input_file.as_posix(),code)
        self.assertNotIn('E:/workspace/DCCM/',code)
        self.assertIn('all_results.sum(axis=1)',code)
        self.assertEqual(result['changed_path_literals'],5)
        self.assertTrue(result['algorithm_ast_unchanged'])
        self.assertFalse(result['algorithm_confirmation_required'])
        self.assertTrue(result['user_requested_original_algorithm'])
        self.assertFalse((p/'results.csv').exists())
        self.assertTrue(all(not c.get('outputs') for c in nb['cells']))

    def test_existing_notebook_is_not_overwritten(self):
        p=self.root/'DCCM';p.mkdir();target=p/'DCCM.ipynb';target.write_text('user content')
        with self.assertRaisesRegex(ValueError,'exists'):prepare(p)
        self.assertEqual(target.read_text(),'user content')

    def test_unsupported_path_does_not_create_partial_notebook(self):
        p=self.root/"user's folder"
        with self.assertRaisesRegex(ValueError,'quote'):prepare(p)
        self.assertFalse(p.exists())


if __name__=='__main__':unittest.main()
