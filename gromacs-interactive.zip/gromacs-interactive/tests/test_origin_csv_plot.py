import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
import uuid

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from origin_csv_plot import load_job


class CsvPlotTests(unittest.TestCase):
    def setUp(self):
        self.parent = Path(os.environ.get('GMX_TEST_TMP', tempfile.gettempdir())).resolve()
        self.root = self.parent / ('origin-csv-test-' + uuid.uuid4().hex)
        self.root.mkdir(mode=0o777)
        self.addCleanup(self.cleanup)
        self.csv = self.root / 'rmsd.csv'
        self.csv.write_text('time_ns,rmsd_nm,sd_nm\n0,0.01,0.001\n1,0.02,0.002\n', encoding='utf-8')
        self.job = {'csv': str(self.csv), 'csv_sha256': hashlib.sha256(self.csv.read_bytes()).hexdigest(),
                    'chart_confirmed': True, 'template_confirmed': True, 'chart': 'line',
                    'x_column': 'time_ns', 'stem': 'rmsd', 'smooth_points': 1,
                    'series': [{'label': 'RMSD', 'y_column': 'rmsd_nm', 'color': '#173B69'}]}

    def cleanup(self):
        if self.root.resolve().parent != self.parent:
            raise RuntimeError('Unexpected cleanup directory')
        shutil.rmtree(self.root)

    def load(self):
        p = self.root / 'job.json'
        p.write_text(json.dumps(self.job), encoding='utf-8')
        return load_job(p)

    def rehash(self):
        self.job['csv_sha256'] = hashlib.sha256(self.csv.read_bytes()).hexdigest()

    def test_single_trace_line_preserves_values_no_error_column(self):
        before = self.csv.read_bytes()
        _, _, values = self.load()
        self.assertEqual(values, {'time_ns': [0, 1], 'rmsd_nm': [0.01, 0.02]})
        self.assertEqual(self.csv.read_bytes(), before)

    def test_single_trajectory_cannot_be_replicate_sd_band(self):
        self.job['chart'] = 'mean-sd'
        self.job['series'][0].update(sd_column='sd_nm', independent_replicates=1,
                                    error_semantics='sample_sd_between_replicates')
        with self.assertRaisesRegex(ValueError, '独立重复'): self.load()

    def test_valid_precomputed_replicate_sd_mapping(self):
        self.job['chart'] = 'mean-sd'
        self.job['series'][0].update(sd_column='sd_nm', independent_replicates=3,
                                    error_semantics='sample_sd_between_replicates')
        self.assertEqual(self.load()[2]['sd_nm'], [0.001, 0.002])

    def test_stale_csv_rejected(self):
        self.csv.write_text(self.csv.read_text() + '2,0.03,0.004\n')
        with self.assertRaisesRegex(ValueError, '已变更'): self.load()

    def test_count_axis_rejects_fractional_and_negative_values(self):
        self.job['y_axis_kind'] = 'count'
        for bad in ('0.2', '-1'):
            self.csv.write_text('time_ns,rmsd_nm\n0,0\n1,'+bad+'\n')
            self.rehash()
            with self.assertRaisesRegex(ValueError, '非负整数'): self.load()

    def test_count_metadata_and_page_size(self):
        self.csv.write_text('time_ns,rmsd_nm\n0,0\n1,2\n')
        self.rehash()
        self.job.update(y_axis_kind='count', page_size={'width': 11000, 'height': 9000},
                        column_metadata={'time_ns': {'long_name': 'Time', 'units': 'ns'}})
        self.assertEqual(self.load()[2]['rmsd_nm'], [0, 2])
        self.job['page_size']['height'] = -1
        with self.assertRaisesRegex(ValueError, '尺寸'): self.load()

    def test_nan_rejected(self):
        self.csv.write_text('time_ns,rmsd_nm\n0,0.01\n1,nan\n')
        self.rehash()
        with self.assertRaisesRegex(ValueError, '非有限'): self.load()

    def test_duplicate_axis_rejected(self):
        self.csv.write_text('time_ns,rmsd_nm\n0,0.01\n0,0.02\n')
        self.rehash()
        with self.assertRaisesRegex(ValueError, '严格递增'): self.load()

    def test_unconfirmed_chart_rejected(self):
        self.job['chart_confirmed'] = False
        with self.assertRaisesRegex(ValueError, '尚未确认'): self.load()

    def test_sem_does_not_pass_as_sd(self):
        self.job['chart'] = 'mean-sd'
        self.job['series'][0].update(sd_column='sd_nm', independent_replicates=3, error_semantics='SEM')
        with self.assertRaisesRegex(ValueError, '样本 SD'): self.load()

    def test_negative_sd_rejected(self):
        self.csv.write_text('time_ns,rmsd_nm,sd_nm\n0,0.01,-0.001\n1,0.02,0.002\n')
        self.rehash()
        self.job['chart'] = 'mean-sd'
        self.job['series'][0].update(sd_column='sd_nm', independent_replicates=3,
                                    error_semantics='sample_sd_between_replicates')
        with self.assertRaisesRegex(ValueError, '负数'): self.load()


if __name__ == '__main__':
    unittest.main()
