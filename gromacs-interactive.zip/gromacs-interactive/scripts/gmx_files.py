"""Python 3 stdlib helpers: read-only inventory and reviewed TOP count changes.

This is a coordinate-label check, NOT a topology preprocessor or parameterizer.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import difflib
import hashlib
import json
import math
import os
from pathlib import Path
import re
import tempfile
import uuid


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def text(path):
    return Path(path).read_bytes().decode('utf-8-sig')


def gro(path):
    lines = text(path).splitlines()
    if len(lines) < 3:
        raise ValueError('GRO 文件不完整')
    n = int(lines[1].strip())
    if n <= 0 or len(lines) != n + 3:
        raise ValueError('GRO 声明原子数与行数不一致或为空')
    atoms = []
    for line in lines[2:2+n]:
        if len(line) < 44:
            raise ValueError('GRO 原子行太短')
        resid = int(line[:5]); resname = line[5:10].strip(); name = line[10:15].strip()
        if not resname or not name:
            raise ValueError('GRO 原子名或残基名为空')
        coords = [float(line[a:b]) for a,b in ((20,28),(28,36),(36,44))]
        if not all(math.isfinite(x) for x in coords):
            raise ValueError('GRO 坐标含非有限值')
        atoms.append((resid, resname, name))
    box = [float(x) for x in lines[-1].split()]
    if len(box) not in (3,9) or not all(math.isfinite(x) for x in box):
        raise ValueError('GRO 盒子行无效')
    return atoms, box


def sections(source):
    result = []; current = None
    for line in source.splitlines():
        code = line.split(';',1)[0].strip()
        match = re.fullmatch(r'\[\s*([^\]]+)\s*\]', code)
        if match:
            current = match.group(1).strip().lower()
        elif code and not code.startswith('#'):
            result.append((current,code.split()))
    return result


def inventory(directory):
    directory = Path(directory).resolve()
    if not directory.is_dir():
        raise ValueError('输入目录不存在')
    entries = []
    for path in sorted(directory.iterdir()):
        if not path.is_file():
            continue
        item = {'path':str(path),'size_bytes':path.stat().st_size}
        suffix = path.suffix.lower()
        # Large binary trajectories are listed only; not read or hashed here.
        if suffix in ('.gro','.pdb','.mdp','.top','.itp'):
            item['sha256'] = sha(path)
            try:
                source = text(path)
                if suffix == '.gro':
                    atoms,box = gro(path)
                    item.update(atom_count=len(atoms),box=box,
                                atoms_by_resname=dict(Counter(a[1] for a in atoms)))
                elif suffix == '.pdb':
                    atoms=[s for s in source.splitlines() if s.startswith(('ATOM  ','HETATM'))]
                    item.update(atom_records=len(atoms),
                                models=max(1,sum(s.startswith('MODEL ') for s in source.splitlines())),
                                chains=sorted(set(s[21:22] for s in atoms)))
                elif suffix == '.mdp':
                    values={}
                    for line in source.splitlines():
                        code=line.split(';',1)[0]
                        if '=' in code:
                            k,v=code.split('=',1); values[k.strip().lower().replace('_','-')]=v.strip()
                    item['mdp']=values
                else:
                    data=sections(source)
                    item['molecule_types']=[v[0] for s,v in data if s=='moleculetype']
                    item['direct_includes']=[{'path':s,'exists_relative_to_file':(path.parent/s).is_file()}
                        for s in re.findall(r'^\s*#include\s+"([^"]+)"',source,re.M)]
                    item['atoms_section_records']=sum(s=='atoms' for s,_ in data)
                    item['molecules_rows']=[v for s,v in data if s=='molecules']
                    definitions={}; duplicates=[]
                    for s,v in data:
                        if s=='atomtypes':
                            if v[0] in definitions:
                                duplicates.append({'name':v[0],
                                                   'textually_identical':definitions[v[0]]==v})
                            definitions[v[0]]=v
                    item['duplicate_atomtypes_within_file']=duplicates
            except (ValueError,IndexError,UnicodeError) as e:
                item['inspection_error']=str(e)
        entries.append(item)
    return {'directory':str(directory),'files':entries,
            'limits':['基础格式检查不证明化学/力场正确',
                      'include 仅按相对路径检查，尚未展开条件或搜索 GMXLIB',
                      '未选择任何体系设置，未修改输入，未启动 GROMACS']}


def signature(atoms):
    """Relative residue boundaries permit renumbering, not atom reordering."""
    result=[]; last=None; block=-1
    for resid,resname,name in atoms:
        if (resid,resname)!=last:
            block+=1
        last=(resid,resname)
        result.append((block,resname,name))
    return result


def molecule_rows(coordinate, mapping):
    mapping=Path(mapping).resolve()
    document=json.loads(text(mapping))
    templates=[]; evidence={str(mapping):sha(mapping)}
    names=set()
    for item in document['templates']:
        name=item['name']
        if not re.fullmatch(r'[A-Za-z0-9_.+\-]+',name) or name in names:
            raise ValueError('moleculetype 名称无效或重复')
        names.add(name)
        path=(mapping.parent/item['gro']).resolve()
        atoms,_=gro(path)
        templates.append((name,len(atoms),signature(atoms)))
        evidence[str(path)]=sha(path)
    if not templates:
        raise ValueError('缺少单分子模板')
    atoms,_=gro(coordinate)
    evidence[str(Path(coordinate).resolve())]=sha(coordinate)
    rows=[]; position=0
    while position<len(atoms):
        matches=[]
        for name,length,labels in templates:
            if position+length<=len(atoms) and signature(atoms[position:position+length])==labels:
                matches.append((name,length))
        if len(matches)!=1:
            raise ValueError('坐标原子位置 %d 匹配 %d 个模板，拒绝猜测' % (position+1,len(matches)))
        name,length=matches[0]
        if rows and rows[-1][0]==name:
            rows[-1][1]+=1
        else:
            rows.append([name,1])
        position+=length
    return rows,evidence


def replace_molecules(source,rows):
    lines=source.splitlines(keepends=True)
    starts=[]; system=False
    for i,line in enumerate(lines):
        code=line.split(';',1)[0].strip()
        match=re.fullmatch(r'\[\s*([^\]]+)\s*\]',code)
        if match:
            name=match.group(1).strip().lower()
            if name=='system': system=True
            if name=='molecules':
                if not system: raise ValueError('molecules 必须在 system 之后')
                starts.append(i)
    if len(starts)!=1:
        raise ValueError('只支持恰好一个末尾 molecules 段')
    start=starts[0]
    for line in lines[start+1:]:
        code=line.split(';',1)[0].strip()
        if code.startswith(('#','[')):
            raise ValueError('molecules 内含预处理或后续段，需专门解析')
        if code:
            fields=code.split()
            if len(fields)!=2 or not fields[1].isdigit():
                raise ValueError('已有 molecules 行无法可靠解析')
    # Detect conditional context, even if the directive precedes this section.
    depth=0
    for line in lines[:start]:
        code=line.strip()
        if re.match(r'#\s*(if|ifdef|ifndef)\b',code): depth+=1
        if re.match(r'#\s*endif\b',code): depth-=1
        if depth<0: raise ValueError('预处理条件不平衡')
    if depth: raise ValueError('molecules 位于条件分支中，需专门解析')
    old=[]
    for line in lines[start+1:]:
        fields=line.split(';',1)[0].split()
        if fields: old.append([fields[0],int(fields[1])])
    if old==rows:
        return source
    newline='\r\n' if '\r\n' in source else '\n'
    header=''.join(lines[:start+1])
    if not header.endswith(('\r','\n')): header+=newline
    return header+'; Reconciled against ordered single-molecule templates'+newline+''.join(
        '%-24s %d%s'%(name,count,newline) for name,count in rows)


def proposal(top,coordinate,mapping):
    top=Path(top).resolve(); coordinate=Path(coordinate).resolve(); mapping=Path(mapping).resolve()
    rows,evidence=molecule_rows(coordinate,mapping)
    evidence[str(top)]=sha(top)
    source=text(top); replacement=replace_molecules(source,rows)
    # Preserve UTF-8 BOM when present.
    bom=top.read_bytes().startswith(b'\xef\xbb\xbf')
    return {'schema_version':1,'top':str(top),'gro':str(coordinate),'mapping':str(mapping),
            'source_hashes':evidence,'rows':rows,'replacement':replacement,'utf8_bom':bom,
            'changed':replacement!=source,'diff':''.join(difflib.unified_diff(
                source.splitlines(keepends=True),replacement.splitlines(keepends=True),
                fromfile=str(top),tofile=str(top)+' (proposed)'))}


def apply(path):
    planned=json.loads(text(path))
    for source,expected in planned['source_hashes'].items():
        if sha(source)!=expected:
            raise ValueError('建议生成后输入已变更，请重新检查: '+source)
    current=proposal(planned['top'],planned['gro'],planned['mapping'])
    if current!=planned:
        raise ValueError('建议内容与当前输入重新计算的结果不一致')
    top=Path(planned['top'])
    if not planned['changed']:
        return {'changed':False,'top':str(top),'message':'TOP 已与实际组成一致，无需修改'}
    if top.is_symlink():
        raise ValueError('不直接覆盖符号链接 TOP')
    before=top.read_bytes()
    backup=top.with_name(top.name+'.bak-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8])
    with backup.open('xb') as f: f.write(before)
    content=planned['replacement'].encode('utf-8-sig' if planned['utf8_bom'] else 'utf-8')
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(dir=top.parent,prefix=top.name+'.',suffix='.tmp',delete=False) as f:
            temporary=Path(f.name); f.write(content); f.flush(); os.fsync(f.fileno())
        if sha(top)!=planned['source_hashes'][str(top)]:
            raise ValueError('写回前 TOP 已被其他程序修改')
        os.replace(temporary,top)
    finally:
        if temporary and temporary.exists(): temporary.unlink()
    return {'changed':True,'top':str(top),'backup':str(backup),'sha256':sha(top),'rows':planned['rows']}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    sub=ap.add_subparsers(dest='action',required=True)
    parser=sub.add_parser('inspect'); parser.add_argument('--directory',required=True)
    parser=sub.add_parser('top-propose')
    for arg in ('top','gro','mapping','proposal'): parser.add_argument('--'+arg,required=True)
    parser=sub.add_parser('top-apply'); parser.add_argument('--proposal',required=True)
    ns=ap.parse_args()
    try:
        if ns.action=='inspect': result=inventory(ns.directory)
        elif ns.action=='top-propose':
            result=proposal(ns.top,ns.gro,ns.mapping)
            output=Path(ns.proposal).resolve()
            if output.suffix.lower()!='.json':
                raise ValueError('建议文件必须使用 .json 扩展名')
            if str(output) in result['source_hashes'] or str(output.with_suffix('.diff')) in result['source_hashes']:
                raise ValueError('建议文件不得覆盖输入')
            if output.exists() or output.with_suffix('.diff').exists():
                raise ValueError('建议输出已存在，请使用新文件名')
            output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
            output.with_suffix('.diff').write_text(result['diff'],encoding='utf-8',newline='')
        else: result=apply(ns.proposal)
        print(json.dumps(result,ensure_ascii=False,indent=2))
    except (OSError,ValueError,KeyError,TypeError) as e:
        ap.exit(2,'错误: '+str(e)+'\n')


if __name__=='__main__': main()
