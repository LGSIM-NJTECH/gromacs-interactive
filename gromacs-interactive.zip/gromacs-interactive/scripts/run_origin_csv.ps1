param([Parameter(Mandatory=$true)][string]$Job,
      [ValidateSet('origin_csv_plot.py','origin_saltbridge.py')][string]$WorkerName='origin_csv_plot.py')
$ErrorActionPreference='Stop'
$jobFile=(Resolve-Path -LiteralPath $Job).Path
$worker=(Join-Path $PSScriptRoot $WorkerName)
if ($jobFile.Contains('"') -or $worker.Contains('"')) { throw 'Unsupported quote in path' }
$plan=Get-Content -LiteralPath $jobFile -Raw -Encoding utf8 | ConvertFrom-Json
$out=[System.IO.Path]::GetFullPath($plan.output_dir)
if ((Test-Path -LiteralPath (Join-Path $out ($plan.stem+'.opju'))) -or (Test-Path -LiteralPath (Join-Path $out 'origin-readback.json'))) { throw 'Output exists; use a new output directory' }
New-Item -ItemType Directory -Path $out -Force | Out-Null
$app=$null
try {
  # Origin.Application creates an owned instance; never use ApplicationSI or attach/reset a user's project.
  $app=New-Object -ComObject Origin.Application
  $app.Visible=0
  $bootstrap=Join-Path $out 'origin-bootstrap.py'
  $workerLiteral=ConvertTo-Json -InputObject $worker -Compress
  $jobLiteral=ConvertTo-Json -InputObject $jobFile -Compress
  $errorLiteral=ConvertTo-Json -InputObject (Join-Path $out 'origin-error.log') -Compress
  $bootstrapCode=@"
import runpy, traceback
from pathlib import Path
try:
    runpy.run_path($workerLiteral, init_globals={'GMX_JOB_PATH': $jobLiteral}, run_name='__main__')
except BaseException:
    Path($errorLiteral).write_text(traceback.format_exc(), encoding='utf-8')
    raise
"@
  [System.IO.File]::WriteAllText($bootstrap,$bootstrapCode,[System.Text.UTF8Encoding]::new($false))
  $statement='run -pyf "'+$bootstrap.Replace('\','/')+'";'
  $ok=$app.Execute($statement)
  [string]$ok | Set-Content -LiteralPath (Join-Path $out 'origin-execute-result.txt') -Encoding ascii
  $report=Join-Path $out 'origin-readback.json'
  if (-not (Test-Path -LiteralPath $report)) { throw 'Origin did not produce verified output; inspect origin-error.log' }
  $result=Get-Content -LiteralPath $report -Raw -Encoding utf8 | ConvertFrom-Json
  if ($result.status -ne 'passed') { throw 'Origin readback failed' }
  $result | ConvertTo-Json -Depth 8
} finally {
  if ($null -ne $app) { $app.Exit() | Out-Null; [void][System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($app) }
}
