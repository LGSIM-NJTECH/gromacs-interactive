"""CSV validation + native Origin plotting worker (executed inside owned Origin).

Outside Origin: python origin_csv_plot.py JOB.json --check-only
Inside a new Origin.Application: set string __gmx_plot_job$, then run -pyf this file.
Does not calculate MD observables or fabricate replicate uncertainty.
"""
import csv
import hashlib
import json
import math
from pathlib import Path
import re
from statistics import mean, stdev
import sys
import traceback


STYLE = "wide-grid-20261106"
PAGE_SIZE = {"width": 14000, "height": 6420}
SERIES_COLORS = ("#173B69", "#B74638")
REFERENCE_PRESETS = {
    "rmsd": {"height": 6420, "frame": (9, 4.2, 89, 82), "band_transparency": 50, "headroom": .53},
    "rg": {"height": 6520, "frame": (8.5, 4, 89.5, 81), "band_transparency": 50, "headroom": .08},
    "rmsf": {"height": 6830, "frame": (10, 10, 85, 75), "band_transparency": 18, "headroom": .40},
}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def comparison_job(source, out, metric, smoothing_ns=0):
    """Verify the replicate summary and prepare an Origin job with the historical layout."""
    source, out = Path(source).resolve(), Path(out).resolve()
    labels = {"rmsd": "RMSD", "rg": "Rg", "rmsf": "RMSF"}
    if metric not in labels:
        raise ValueError("请选择 RMSD、Rg 或 RMSF")
    x_column = "residue" if metric == "rmsf" else "time_ns"
    series = []
    expected_hash = digest(source)
    with source.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        fields = reader.fieldnames or []
        if x_column not in fields or len(fields) != len(set(fields)):
            raise ValueError(f"CSV 必须包含唯一列名及横轴列 {x_column}")
        replica_columns = {}
        for group in ("WT", "MUT"):
            y, sd = f"{group}_mean_nm", f"{group}_SD_nm"
            replicas = [col for col in fields if re.fullmatch(rf"{group}_rep[1-9]\d*_nm", col)]
            if len(replicas) < 2 or y not in fields or sd not in fields:
                raise ValueError(f"{group} 至少需要两条平行列，以及 {y} 和 {sd}")
            series.append({"label": group, "y_column": y, "sd_column": sd,
                           "independent_replicates": len(replicas),
                           "error_semantics": "sample_sd_between_replicates"})
            replica_columns[group] = replicas
        for line, row in enumerate(reader, 2):
            for entry in series:
                group = entry["label"]
                try:
                    values = [float(row[col]) for col in replica_columns[group]]
                    y, sd = float(row[entry["y_column"]]), float(row[entry["sd_column"]])
                    valid = all(math.isfinite(v) and v >= 0 for v in (*values, y, sd))
                except (TypeError, ValueError):
                    valid = False
                if (not valid or not math.isclose(mean(values), y, rel_tol=0, abs_tol=1e-7) or
                        not math.isclose(stdev(values), sd, rel_tol=0, abs_tol=1e-7)):
                    raise ValueError(f"CSV 第 {line} 行 {group} 均值或样本 SD 与平行值不一致")
    if digest(source) != expected_hash:
        raise ValueError("CSV 在核对期间发生变化")
    job = dict(csv=str(source), csv_sha256=expected_hash, output_dir=str(out), stem=f"WT_MUT_{labels[metric]}",
               chart="mean-sd", chart_confirmed=True, template_confirmed=True, x_column=x_column,
               xlabel="Residue number" if metric == "rmsf" else "Time (ns)",
               ylabel=f"{labels[metric]} (nm)", series=series, metric=metric, background="transparent")
    if metric == "rmsf":
        job["x_axis_kind"] = "residue"
    if smoothing_ns:
        job.update(display_smoothing_ns=smoothing_ns, x_unit="ns")
    return job


def load_job(path):
    path = Path(path).resolve()
    job = json.loads(path.read_text(encoding="utf-8-sig"))
    if job.get("chart_confirmed") is not True or job.get("template_confirmed") is not True:
        raise ValueError("图型及模板选择尚未确认")
    if job.get("chart") not in ("line", "scatter-line", "mean-sd"):
        raise ValueError("不支持的图型")
    source = Path(job["csv"]).resolve()
    if digest(source) != job["csv_sha256"]:
        raise ValueError("CSV 已变更，重新核对列映射和图型选择")
    with source.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        fields = reader.fieldnames
        if not fields or len(fields) != len(set(fields)):
            raise ValueError("CSV 列名为空或重复")
        raw = list(reader)
    series = job["series"]
    if not raw or not series:
        raise ValueError("CSV 或绘图序列为空")
    columns = [job["x_column"]] + [s["y_column"] for s in series]
    if job["chart"] == "mean-sd":
        for s in series:
            if s.get("independent_replicates", 0) < 2 or s.get("error_semantics") != "sample_sd_between_replicates":
                raise ValueError("误差带需要独立重复及明确的平行间样本 SD；单轨迹不能冒充重复")
            columns.append(s["sd_column"])
    if any(c not in fields for c in columns):
        raise ValueError("CSV 缺少已选择的绘图列")
    values = {c: [float(r[c]) for r in raw] for c in set(columns)}
    if any(not math.isfinite(v) for a in values.values() for v in a):
        raise ValueError("CSV 含非有限值")
    x = values[job["x_column"]]
    if len(x) < 2 or any(b <= a for a, b in zip(x, x[1:])):
        raise ValueError("横轴必须至少两点且严格递增")
    if job.get("x_axis_kind") == "residue" and any(not v.is_integer() for v in x):
        raise ValueError("RMSF 的横轴必须使用整数残基编号")
    for index, s in enumerate(series):
        if index < len(SERIES_COLORS):
            s.setdefault("color", SERIES_COLORS[index])
        if not re.fullmatch(r"#[0-9a-fA-F]{6}", s["color"]):
            raise ValueError("颜色必须为 HEX RGB")
        if job["chart"] == "mean-sd" and any(v < 0 for v in values[s["sd_column"]]):
            raise ValueError("SD 不能为负数")
    if job.get("smooth_points", 1) != 1:
        raise ValueError("本版只验证原始曲线；平滑需另行确认并逐项实现")
    if "display_smoothing_ns" in job:
        window = job["display_smoothing_ns"]
        if (job["chart"] != "mean-sd" or job.get("x_axis_kind") == "residue" or
                job.get("x_unit", job.get("column_metadata", {}).get(job["x_column"], {}).get("units")) != "ns" or
                isinstance(window, bool) or not isinstance(window, (int, float)) or
                not math.isfinite(window) or not 0 < window <= x[-1] - x[0]):
            raise ValueError("仅时间单位为 ns 的均值误差带图支持已确认的显示平滑窗口")
        interval = (x[-1] - x[0]) / (len(x) - 1)
        if window < 2 * interval or any(
                not math.isclose(b - a, interval, rel_tol=1e-6, abs_tol=1e-10) for a, b in zip(x, x[1:])):
            raise ValueError("显示平滑要求等间隔时间点，窗口至少跨两个采样间隔")
    if job.get("background", "white") not in ("white", "transparent") or job.get("reference_line") is not None:
        raise ValueError("支持白底或透明底，不自动加入参考线")
    if not re.fullmatch(r"[\w.-]+", job["stem"]) or job["stem"] in (".", ".."):
        raise ValueError("输出主文件名无效")
    if job.get("y_axis_kind") == "count":
        if job["chart"] == "mean-sd" or any(v < 0 or not v.is_integer() for s in series for v in values[s["y_column"]]):
            raise ValueError("原始计数图需要非负整数，不能使用均值误差带")
    for name, meta in job.get("column_metadata", {}).items():
        if name not in values or any(k not in ("long_name", "units") or not isinstance(v, str) for k, v in meta.items()):
            raise ValueError("列标签映射无效")
    size = job.get("page_size", PAGE_SIZE)
    if set(size) != {"width", "height"} or any(isinstance(v, bool) or not isinstance(v, (int, float)) or not 1000 <= v <= 30000 for v in size.values()):
        raise ValueError("Origin 页面尺寸无效")
    return job, source, values


def major_step(span, intervals):
    target = span / intervals
    power = 10 ** math.floor(math.log10(target))
    return next(factor * power for factor in (1, 2, 2.5, 5, 10) if factor * power >= target)


def centered_mean(values, half_window):
    cumulative = [0.0]
    for value in values:
        cumulative.append(cumulative[-1] + value)
    output = []
    for i in range(len(values)):
        left = max(0, i - half_window)
        right = min(len(values), i + half_window + 1)
        output.append((cumulative[right] - cumulative[left]) / (right - left))
    return output


def band_color(color):
    # Mix the line hue with white to keep overlaps light in a transparent export.
    channels = (int(color[i:i+2], 16) for i in (1, 3, 5))
    return "#" + "".join(f"{round(.28 * c + .72 * 255):02x}" for c in channels)


def render(path):
    import originpro as op
    job, source, values = load_job(path)
    out = Path(job["output_dir"]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    stem = job["stem"]
    metric = job.get("metric") or re.split(r"[_-]", stem.lower(), maxsplit=1)[0]
    preset = REFERENCE_PRESETS.get(metric)
    background = job.get("background", "white")
    project, png = out / (stem + ".opju"), out / (stem + ".png")
    if project.exists() or png.exists():
        raise ValueError("输出已存在；使用新目录，不覆盖旧结果")
    if not op.lt_exec("sec -poc 30;") or op.lt_float("run.isOCready()") < 0.5:
        raise RuntimeError("Origin 尚未就绪")
    op.new()  # only in the instance created by run_origin_csv.ps1
    for page in list(op.pages("w")):
        page.destroy()
    sheet = op.new_sheet("w", lname=stem + " CSV data")
    imported = list(values)
    # Deterministic order: x then selected y/SD; no unused CSV columns are silently plotted.
    xcol = job["x_column"]
    x = values[xcol]
    imported = [xcol] + sorted(c for c in imported if c != xcol)
    for i, name in enumerate(imported):
        meta = job.get("column_metadata", {}).get(name, {})
        sheet.from_list(i, values[name], lname=meta.get("long_name", name), units=meta.get("units", ""), axis="X" if i == 0 else "Y")
    graph = op.new_graph(template="line", lname=stem)
    size = job.get("page_size", {"width": PAGE_SIZE["width"], "height": preset["height"]} if preset else PAGE_SIZE)
    page_color = "0" if background == "transparent" else "color(white)"
    graph.lt_exec(f"page.kar=0;page.width={size['width']};page.height={size['height']};page.baseColor={page_color};")
    layer = graph[0]
    layer.set_int("unit", 1)
    frame = preset["frame"] if preset else (10, 4.5, 87, 80)
    for key, value in zip(("left", "top", "width", "height"), frame):
        layer.set_float(key, value)
    plot_columns, derived_columns = [], {}
    # Bounds are Origin-native worksheet columns/plots, not an embedded bitmap.
    if job["chart"] == "mean-sd":
        for s in job["series"]:
            y, sd = values[s["y_column"]], values[s["sd_column"]]
            upper, lower = [a+b for a, b in zip(y, sd)], [a-b for a, b in zip(y, sd)]
            start = sheet.cols
            sheet.from_list(start, upper, lname=s["label"] + " upper mean+SD")
            sheet.from_list(start+1, lower, lname=s["label"] + " lower mean-SD")
            derived_columns.update({start: upper, start+1: lower})
            top = layer.add_plot(sheet, start, 0, type="l")
            bottom = layer.add_plot(sheet, start+1, 0, type="l")
            fill = band_color(s["color"]) if preset else s["color"]
            transparency = preset["band_transparency"] if preset else 78
            for plot in (top, bottom):
                plot.color = fill
                plot.transparency = transparency
                plot.set_cmd("-wp 0.35")
            top.set_fill_area(op.ocolor(fill), 9, op.ocolor(fill))
            top.set_cmd(f"-paaf {transparency if preset else 73}")
            plot_columns.extend([start, start+1])
    line_ids = []
    smoothing = job.get("display_smoothing_ns")
    for s in job["series"]:
        col = imported.index(s["y_column"])
        if smoothing is not None:
            interval = (x[-1] - x[0]) / (len(x) - 1)
            half_window = math.floor(smoothing / (2 * interval) + 1e-9)
            displayed = centered_mean(values[s["y_column"]], half_window)
            col = sheet.cols
            sheet.from_list(col, displayed, lname=f"{s['label']} display mean ({smoothing:g} ns)")
            derived_columns[col] = displayed
        plot = layer.add_plot(sheet, col, 0, type=202 if job["chart"] == "scatter-line" else "l")
        plot.color = s["color"]
        plot.set_cmd("-wp 1.7" if job["chart"] == "mean-sd" else "-wp 2.8")
        if job["chart"] == "scatter-line":
            plot.symbol_kind = 2
            plot.symbol_size = 5
        plot_columns.append(col)
        line_ids.append(len(layer.plot_list()))
    ys = [v for s in job["series"] for v in values[s["y_column"]]]
    if job["chart"] == "mean-sd":
        ys = [v for s in job["series"] for y, d in zip(values[s["y_column"]], values[s["sd_column"]]) for v in (y-d, y+d)]
    low, high = min(ys), max(ys)
    margin = (high-low)*0.08 or max(abs(high)*0.08, 0.01)
    if job.get("x_axis_kind") == "residue":
        span = x[-1] - x[0]
        step = max(1, math.ceil(major_step(span, 8)))
        lower = max(math.floor(x[0] / step) * step, math.floor(x[0] - 0.02 * span))
        layer.set_xlim(lower, math.ceil(x[-1] + 0.02 * span), step)
    else:
        layer.set_xlim(x[0], x[-1], (x[-1]-x[0])/5)
    if job.get("y_axis_kind") == "count":
        step = max(1, math.ceil(major_step(max(1, high), 6)))
        layer.set_ylim(0, (math.floor(high/step)+1)*step, step)
    else:
        headroom = max(margin, (high-low) * preset["headroom"]) if preset and job["chart"] == "mean-sd" else margin
        step = major_step(high - low + margin + headroom, 8)
        bottom = math.floor((low - margin) / step) * step
        top = math.ceil((high + headroom) / step) * step
        layer.set_ylim(max(0, bottom) if low >= 0 else bottom, top, step)
    layer.axis("x").title = job["xlabel"]
    layer.axis("y").title = job["ylabel"]
    layer.set_int("x.showgrids", 1)
    layer.set_int("y.showgrids", 1)
    layer.activate()
    for axis in ("x", "y"):
        prefix = f"layer.{axis}"
        op.lt_exec(
            f"{prefix}.grid.majorColor=color(207,214,222);{prefix}.grid.majorWidth=1.25;"
            f"{prefix}.thickness=1.25;{prefix}.ticks=2;{prefix}.ticklength=4;"
            f"{prefix}.label.font=font(Times New Roman);{prefix}.label.pt=25;"
        )
    op.lt_exec("xb.font=font(Times New Roman);yl.font=font(Times New Roman);xb.fsize=32;yl.fsize=32;")
    legend = layer.label("Legend")
    if legend:
        legend.text = "\n".join("\\l(%d) %s" % (i, s["label"]) for i, s in zip(line_ids, job["series"]))
        op.lt_exec(
            f"legend.background={0 if preset else 4};legend.font=font(Times New Roman);legend.fsize=28;legend.attach=2;"
            "legend.x1=layer.x.from+0.018*(layer.x.to-layer.x.from);"
            "legend.y1=layer.y.to-0.035*(layer.y.to-layer.y.from);"
        )
    for i, name in enumerate(imported):
        actual = sheet.to_list(i)
        if len(actual) != len(values[name]) or any(not math.isclose(float(a), b, rel_tol=0, abs_tol=1e-12) for a,b in zip(actual, values[name])):
            raise RuntimeError("Origin 数据回读与 CSV 不一致：" + name)
    bindings = [p.lt_range() for p in layer.plot_list()]
    colors = [list(p.color) for p in layer.plot_list()]
    if len(bindings) != len(plot_columns):
        raise RuntimeError("Origin 曲线数量不一致")
    if not op.save(str(project)):
        raise RuntimeError("Origin OPJU 导出失败")
    if background == "transparent":
        graph.activate()
        op.lt_exec(f'expG2img type:=png name:="{stem}" path:="{out}" tb:=1 width:=2400;')
        if not png.is_file():
            raise RuntimeError("Origin 透明 PNG 导出失败")
        with png.open("rb") as stream:
            header = stream.read(26)
        if len(header) != 26 or header[25] not in (4, 6):
            raise RuntimeError("Origin 透明 PNG 缺少 Alpha 通道")
    elif not graph.save_fig(str(png), type="png", width=2200):
        raise RuntimeError("Origin OPJU/PNG 导出失败")
    # Reopen the saved native project to verify persistence, not just memory state.
    if not op.open(str(project), readonly=True):
        raise RuntimeError("保存后的 Origin 工程无法重新打开")
    pages = list(op.pages("g")); books = list(op.pages("w"))
    saved = books[0][0]
    if len(pages) != 1 or len(books) != 1 or len(pages[0][0].plot_list()) != len(plot_columns):
        raise RuntimeError(f"Origin 保存后的图层结构不一致: graphs={len(pages)}, books={len(books)}, plots={len(pages[0][0].plot_list()) if pages else 0}, expected={len(plot_columns)}")
    for i, name in enumerate(imported):
        actual = saved.to_list(i)
        if len(actual) != len(values[name]) or any(not math.isclose(float(a), b, rel_tol=0, abs_tol=1e-12) for a,b in zip(actual, values[name])):
            raise RuntimeError("Origin 工程重开后数据不一致")
        meta = job.get("column_metadata", {}).get(name, {})
        if saved.get_label(i, "L") != meta.get("long_name", name) or saved.get_label(i, "U") != meta.get("units", ""):
            raise RuntimeError("Origin 工程重开后列标签不一致")
    for i, expected in derived_columns.items():
        actual = saved.to_list(i)
        if len(actual) != len(expected) or any(not math.isclose(float(a), b, rel_tol=0, abs_tol=1e-12) for a, b in zip(actual, expected)):
            raise RuntimeError("Origin 工程重开后派生绘图列不一致")
    if digest(source) != job["csv_sha256"]:
        raise RuntimeError("源 CSV 被改变")
    result = {"status": "passed", "chart": job["chart"], "style": STYLE, "rows": len(x),
              "metric_preset": metric if preset else None, "background": background,
              "source_csv": str(source), "source_sha256": digest(source),
              "source_values_equal_after_reopen": True, "plot_bindings": bindings,
              "plot_colors_rgb": colors, "plot_count": len(bindings), "smoothed": smoothing is not None,
              "display_smoothing_ns": smoothing,
              "sd_band_columns_checked": 2 * len(job["series"]) if job["chart"] == "mean-sd" else 0,
              "column_metadata_equal_after_reopen": True, "y_axis_kind": job.get("y_axis_kind"),
              "x_range": [x[0], x[-1]], "y_range": [low, high],
              "outputs": {"opju": str(project), "png": str(png)},
              "validation_scope": "Data readback + project reopen + exports. Visual QA recorded separately."}
    (out / "origin-readback.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def origin_entry():
    import originpro as op
    path = globals().get("GMX_JOB_PATH") or op.lt_str("__gmx_plot_job$")
    out = Path(json.loads(Path(path).read_text(encoding="utf-8-sig"))["output_dir"])
    try:
        render(path)
    except BaseException:
        out.mkdir(parents=True, exist_ok=True)
        (out / "origin-error.log").write_text(traceback.format_exc(), encoding="utf-8")
        raise


if __name__ == "__main__":
    if sys.argv[1:2] == ["--prepare-comparison"]:
        import argparse
        parser = argparse.ArgumentParser(description="核验 WT/MUT 平行数据并生成 Origin 绘图配置")
        parser.add_argument("--prepare-comparison", choices=("rmsd", "rg", "rmsf"), required=True)
        parser.add_argument("csv", type=Path)
        parser.add_argument("output_dir", type=Path)
        parser.add_argument("job", type=Path)
        parser.add_argument("--smoothing-ns", type=float, default=0)
        args = parser.parse_args()
        job = comparison_job(args.csv, args.output_dir, args.prepare_comparison, args.smoothing_ns)
        with args.job.open("x", encoding="utf-8") as stream:
            json.dump(job, stream, ensure_ascii=False, indent=2)
    elif "--check-only" in sys.argv:
        job, source, values = load_job(sys.argv[1])
        print(json.dumps({"valid": True, "source": str(source), "rows": len(next(iter(values.values()))), "chart": job["chart"]}))
    else:
        origin_entry()
