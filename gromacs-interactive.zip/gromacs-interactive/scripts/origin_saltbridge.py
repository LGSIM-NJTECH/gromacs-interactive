"""Native Origin occupancy heatmap; CSV values and labels persist in OPJU."""
import csv
import hashlib
import json
import math
from pathlib import Path
import sys
import traceback


def load_job(path):
    job = json.loads(Path(path).read_text(encoding='utf-8-sig'))
    if job.get('chart') != 'heatmap' or job.get('chart_confirmed') is not True or job.get('template_confirmed') is not True:
        raise ValueError('Heatmap and template must be confirmed')
    source = Path(job['csv']).resolve()
    if hashlib.sha256(source.read_bytes()).hexdigest() != job['csv_sha256']:
        raise ValueError('Source CSV hash changed')
    with source.open(encoding='utf-8-sig',newline='') as stream:
        reader = csv.reader(stream); fields = next(reader); rows = list(reader)
    if len(fields)<2 or fields[0]!='Salt bridge' or len(fields)!=len(set(fields)) or not rows:
        raise ValueError('Require unique pair and real system columns')
    if any(len(row)!=len(fields) or not row[0] for row in rows) or len({r[0] for r in rows})!=len(rows):
        raise ValueError('Incomplete rows or ambiguous residue-pair labels')
    values = [[float(v) for v in row[1:]] for row in rows]
    if any(not math.isfinite(v) or not 0<=v<=1 for row in values for v in row):
        raise ValueError('Occupancy must be finite in [0,1]; missing values need explicit adaptation')
    if job.get('smooth',False) or job.get('color_range')!=[0,1]:
        raise ValueError('Occupancy heatmap requires unchanged cells and color range [0,1]')
    return job, source, fields, rows, values


def render(path):
    import originpro as op
    job, source, fields, rows, values = load_job(path)
    out=Path(job['output_dir']).resolve(); out.mkdir(parents=True,exist_ok=True)
    project,png=out/'saltbridge.opju',out/'saltbridge.png'
    if project.exists() or png.exists(): raise ValueError('Outputs exist; back up first')
    if not op.lt_exec('sec -poc 30;') or op.lt_float('run.isOCready()')<.5: raise RuntimeError('Origin not ready')
    op.new()
    for page in list(op.pages('w')):page.destroy()
    sheet=op.new_sheet('w',lname='Salt bridge occupancy CSV')
    labels=[row[0] for row in rows]
    sheet.from_list(0,labels,lname='Salt bridge')
    for i,name in enumerate(fields[1:],1):sheet.from_list(i,[row[i-1] for row in values],lname=name,axis='Y')
    axes=op.new_sheet('w',lname='Heatmap column labels')
    axes.from_list(0,fields[1:],lname='System')
    mat=op.new_sheet('m',lname='Salt bridge occupancy matrix')
    nr,nc=len(values),len(values[0])
    mat.shape=(nr,nc)
    mat.obj.MatrixObjects(0).SetData(values)
    def matrix_values(ms):
        return [list(row) for row in ms.obj.MatrixObjects(0).GetData()]
    if matrix_values(mat)!=values:raise RuntimeError('Origin changed matrix dimensions or values')
    mat.set_label(0,'Occupancy')
    mat.xymap=(1,nc,1,nr)
    graph=op.new_graph(template='Heat_Map.otpu',lname='Salt bridge occupancy')
    graph.lt_exec('page.kar=0;page.width=12000;page.height=9000;')
    layer=graph[0]
    layer.set_int('unit',1)
    for key,value in {'left':30,'top':10,'width':49,'height':77}.items():layer.set_float(key,value)
    plot=layer.add_mplot(mat,0,type=105)
    layer.set_xlim(.5,nc+.5,1);layer.set_ylim(.5,nr+.5,1)
    layer.set_float('x.firstTick',1);layer.set_float('y.firstTick',1)
    layer.set_int('y.reverse',1)
    layer.set_int('x.minorTicks',0);layer.set_int('y.minorTicks',0)
    layer.set_int('x.ticks',0);layer.set_int('y.ticks',0)
    layer.axis('x').title='System';layer.axis('y').title='Salt bridge'
    legend=layer.label('Legend')
    if legend:legend.remove()
    layer.activate()
    commands=['layer.cmap.zmin=0','layer.cmap.zmax=1','layer.cmap.numMajorLevels=20','layer.cmap.numMinorLevels=0','layer.cmap.setLevels(1)','layer.cmap.linkpal=0']
    for i in range(20):
        fraction=i/19
        rgb=[round(a+(b-a)*fraction) for a,b in zip((245,250,250),(0,160,210))]
        commands.append('layer.cmap.color%d=color(%d,%d,%d)'%((i+1,*rgb)))
    commands.extend(['layer.cmap.colorAbove=color(0,160,210)','layer.cmap.colorBelow=color(245,250,250)','layer.cmap.showLines(3)','layer.cmap.showLabels(3)','layer.cmap.updateScale()','layer.x.showgrids=0','layer.y.showgrids=0'])
    op.lt_exec(';'.join(commands)+';')
    # Native editable boundary objects; values are discrete cells, no smoothing.
    for i in range(nr+1):
        op.lt_exec(f'draw -n sbrow{i} -c 0 -w 1 -l {{0.5,{i+.5},{nc+.5},{i+.5}}};')
    for i in range(nc+1):
        op.lt_exec(f'draw -n sbcol{i} -c 0 -w 1 -l {{{i+.5},0.5,{i+.5},{nr+.5}}};')
    for axis in ('x','x2'):
        layer.set_int(axis+'.label.type',2)
        layer.set_str(axis+'.label.dataset',axes.lt_range()+'!col(A)')
        layer.set_float(axis+'.label.rotate',0)
    for axis in ('y','y2'):
        layer.set_int(axis+'.label.type',2)
        layer.set_str(axis+'.label.dataset',sheet.lt_range()+'!col(A)')
    layer.set_int('x.showLabels',2)
    source_ref=sheet.lt_range(); matrix_ref=mat.lt_range(); axes_ref=axes.lt_range()
    binding=plot.lt_range()
    if matrix_values(mat)!=values:raise RuntimeError('Matrix values differ from CSV')
    if not op.save(str(project)) or not graph.save_fig(str(png),type='png',width=2400):raise RuntimeError('Export failed')
    if not op.open(str(project),readonly=True):raise RuntimeError('Saved project reopen failed')
    saved=op.find_sheet('w',source_ref);saved_mat=op.find_sheet('m',matrix_ref);saved_axes=op.find_sheet('w',axes_ref)
    if saved.to_list(0)!=labels or saved_axes.to_list(0)!=fields[1:]:raise RuntimeError('Saved labels differ')
    for i in range(1,len(fields)):
        if saved.to_list(i)!=[row[i-1] for row in values]:raise RuntimeError('Saved worksheet values differ')
    if matrix_values(saved_mat)!=values:raise RuntimeError('Saved matrix differs')
    graphs=list(op.pages('g'))
    if len(graphs)!=1 or len(graphs[0][0].plot_list())!=1:raise RuntimeError('Unexpected native heatmap structure')
    graphs[0][0].activate()
    limits=[op.lt_float('layer.cmap.zmin'),op.lt_float('layer.cmap.zmax')]
    if limits!=[0.,1.]:raise RuntimeError('Saved color range differs')
    label_types={axis:graphs[0][0].get_int(axis+'.label.type') for axis in ('x2','y')}
    label_datasets={axis:graphs[0][0].get_str(axis+'.label.dataset') for axis in ('x2','y')}
    if any(v!=2 for v in label_types.values()) or any(not v for v in label_datasets.values()):raise RuntimeError('Saved axis label binding differs')
    if hashlib.sha256(source.read_bytes()).hexdigest()!=job['csv_sha256']:raise RuntimeError('Source CSV modified')
    report={'status':'passed','chart':'heatmap','rows':nr,'systems':fields[1:],'columns':nc,'color_range':limits,'plot_binding':binding,'native_plot_type':105,'source_sha256':job['csv_sha256'],'source_values_equal_after_reopen':True,'labels_equal_after_reopen':True,'axis_label_types':label_types,'axis_label_datasets':label_datasets,'matrix_shape_after_reopen':[len(matrix_values(saved_mat)),len(matrix_values(saved_mat)[0])],'smoothed':False,'outputs':{'opju':str(project),'png':str(png)}}
    (out/'origin-readback.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')


def origin_entry():
    path=globals().get('GMX_JOB_PATH')
    out=Path(json.loads(Path(path).read_text(encoding='utf-8-sig'))['output_dir'])
    try:render(path)
    except BaseException:
        (out/'origin-error.log').write_text(traceback.format_exc(),encoding='utf-8')
        raise


if __name__=='__main__':
    if '--check-only' in sys.argv:
        job,source,fields,rows,values=load_job(sys.argv[1]);print(json.dumps({'valid':True,'rows':len(rows),'systems':fields[1:]}))
    else:origin_entry()
