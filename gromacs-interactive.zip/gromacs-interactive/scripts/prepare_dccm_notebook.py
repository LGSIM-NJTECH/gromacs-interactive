"""Prepare a portable project copy of the user's notebook; do not execute it."""
import argparse
import ast
import hashlib
import json
from pathlib import Path


def source_digest(notebook):
    sources=[(c['cell_type'],''.join(c.get('source',[]))) for c in notebook['cells']]
    return hashlib.sha256(json.dumps(sources,ensure_ascii=False,separators=(',',':')).encode('utf-8')).hexdigest()


def prepare(directory, input_file=None):
    directory=Path(directory).resolve()
    source=Path(__file__).resolve().parents[1]/'assets'/'dccm-originals'/'DCCM.ipynb'
    notebook=json.loads(source.read_text(encoding='utf-8'))
    manifest=json.loads((source.parent/'sources.json').read_text(encoding='utf-8'))
    if source_digest(notebook)!=manifest['notebook_cell_source_sha256']:
        raise ValueError('Bundled original notebook source changed')
    destination=directory/'DCCM.ipynb'; record=directory/'notebook.json'
    if destination.exists() or record.exists():
        raise ValueError('Project notebook exists; verify or back up before preparing')
    input_file=Path(input_file).resolve() if input_file else directory/'results.dat'
    mapping={'E:/workspace/DCCM/results.dat':input_file.as_posix(),
             'E:/workspace/DCCM/results.csv':(directory/'results.csv').as_posix(),
             'E:/workspace/DCCM/results.jpeg':(directory/'results.jpeg').as_posix()}
    if any(any(c in path for c in '\r\n\'"') for path in mapping.values()):
        raise ValueError('Notebook path with quote/newline requires explicit literal adaptation')
    class ReversePaths(ast.NodeTransformer):
        def visit_Constant(self,node):
            if isinstance(node.value,str):
                for old,new in mapping.items():
                    if node.value==new:return ast.copy_location(ast.Constant(value=old),node)
            return node
    changed=0
    for cell in notebook['cells']:
        original=''.join(cell.get('source',[]))
        if cell['cell_type']!='code':continue
        updated=original
        for old,new in mapping.items():updated=updated.replace(old,new)
        if ast.dump(ast.parse(original))!=ast.dump(ReversePaths().visit(ast.parse(updated))):
            raise ValueError('Unexpected change beyond path literals')
        changed+=sum(original.count(old) for old in mapping)
        cell['source']=updated.splitlines(keepends=True)
        cell['outputs']=[];cell['execution_count']=None
    notebook.setdefault('metadata',{})['gromacs_interactive']={
        'algorithm':'original-all9','algorithm_confirmation_required':False,
        'user_requested_original_algorithm':True,
        'note':'Use the user-provided notebook calculation unchanged; only project paths are adapted.'}
    directory.mkdir(parents=True,exist_ok=True)
    destination.write_bytes((json.dumps(notebook,ensure_ascii=False,indent=1)+'\n').encode('utf-8'))
    result={'status':'prepared_not_executed','notebook':str(destination),'input':str(input_file),
            'algorithm':'original-all9','algorithm_confirmation_required':False,
            'user_requested_original_algorithm':True,
            'changed_path_literals':changed,'algorithm_ast_unchanged':True,
            'original_cell_source_sha256':manifest['notebook_cell_source_sha256'],
            'prepared_sha256':hashlib.sha256(destination.read_bytes()).hexdigest()}
    record.write_bytes(json.dumps(result,ensure_ascii=False,indent=2).encode('utf-8'))
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory',required=True)
    parser.add_argument('--input')
    args=parser.parse_args()
    print(json.dumps(prepare(args.directory,args.input),ensure_ascii=False,indent=2))
