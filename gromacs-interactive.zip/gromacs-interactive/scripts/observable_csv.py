"""Export native GROMACS RMSD/RMSF/Rg XVG to CSV without smoothing or statistics."""
import argparse
import csv
from decimal import Decimal, InvalidOperation
import hashlib
import json
import math
from pathlib import Path
import re


def rmsf_stem(begin_ps, end_ps):
    try:
        a, b = Decimal(str(begin_ps)), Decimal(str(end_ps))
    except InvalidOperation as error:
        raise ValueError('时间端点无效') from error
    if not a.is_finite() or not b.is_finite() or a < 0 or b <= a:
        raise ValueError('需要有限的非负起点和大于起点的终点')
    duration = format((b-a)/Decimal(1000), 'f')
    if '.' in duration:
        duration = duration.rstrip('0').rstrip('.')
    return 'rmsf_' + duration + 'ns'


def read_xvg(path, metric):
    text = Path(path).read_text(encoding='utf-8-sig')
    rows, labels = [], {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith('#'): continue
        if line.startswith('&'): raise ValueError('多块 XVG 不可直接合并')
        if line.startswith('@'):
            m = re.fullmatch(r'@\s+([xy])axis\s+label\s+"(.*)"', line)
            if m: labels[m[1]] = m[2]
            m = re.fullmatch(r'@\s*TYPE\s+(\S+)', line, re.I)
            if m and m[1].lower() != 'xy': raise ValueError('仅支持本模块的原生 xy 列格式')
            continue
        values = [float(v) for v in line.split()]
        if len(values) != (5 if metric == 'rg' else 2): raise ValueError('XVG 列数与指标不符')
        if not all(math.isfinite(v) for v in values): raise ValueError('XVG 含 NaN/Inf')
        if any(v < 0 for v in values[1:]): raise ValueError('半径/波动/偏差不能为负数')
        rows.append(values)
    if not rows: raise ValueError('XVG 无数据')
    if any(b[0] <= a[0] for a,b in zip(rows,rows[1:])):
        raise ValueError('横轴重复或乱序；多链残基需先核对链及编号映射')
    if not re.search(r'\bnm\b', labels.get('y', '')): raise ValueError('需确认纵轴单位为 nm')
    if metric == 'rmsf':
        if 'residue' not in labels.get('x','').lower(): raise ValueError('RMSF 横轴必须是残基而非时间或原子')
        if any(r[0] != int(r[0]) for r in rows): raise ValueError('残基编号不是整数')
    elif not re.search(r'Time\s*[\[(]ps[\])]', labels.get('x',''), re.I):
        raise ValueError('本版时间导出需原始 ps 横轴；其他单位先明确适配')
    return rows, labels


def export(path, output, metric, begin_ps=None, end_ps=None):
    if metric not in ('rmsd','rmsf','rg'): raise ValueError('未知指标')
    path, output = Path(path).resolve(), Path(output).resolve()
    if not path.is_file(): raise ValueError('输入不存在')
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    rows, labels = read_xvg(path, metric)
    if metric == 'rmsf':
        if begin_ps is None or end_ps is None: raise ValueError('RMSF 需明确分析区间以生成时长名称')
        stem = rmsf_stem(begin_ps, end_ps)
        if path.stem != stem: raise ValueError('RMSF 文件名与已选区间时长不符')
        header = ['residue_number','rmsf_nm']
        converted = [[int(r[0]),r[1]] for r in rows]
    else:
        stem = metric
        header = ['time_ns','rmsd_nm'] if metric == 'rmsd' else ['time_ns','rg_nm','rg_x_nm','rg_y_nm','rg_z_nm']
        converted = [[r[0]/1000] + r[1:] for r in rows]
        if begin_ps is not None and not math.isclose(rows[0][0],float(begin_ps),abs_tol=1e-8):
            raise ValueError('输出起始时间与所选区间不符')
        if end_ps is not None and not math.isclose(rows[-1][0],float(end_ps),abs_tol=1e-8):
            raise ValueError('输出结束时间与所选区间不符')
    if output.name != stem + '.csv': raise ValueError('CSV 必须沿用对应指标主文件名')
    report = output.with_name(stem + '-csv.json')
    if output.exists() or report.exists(): raise ValueError('输出已存在，使用新目录')
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('x',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f);writer.writerow(header);writer.writerows(converted)
    if hashlib.sha256(path.read_bytes()).hexdigest()!=digest: raise ValueError('输入在处理期间发生变化')
    record={'metric':metric,'source':str(path),'source_sha256':digest,'csv':str(output),
            'csv_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'rows':len(rows),
            'source_axis_labels':labels,'headers':header,'analysis_window_ps':[begin_ps,end_ps],
            'x_range':[converted[0][0],converted[-1][0]],'smoothed':False,'interpolated':False,
            'new_statistics_computed':False}
    report.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    return record


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--metric',choices=['rmsd','rmsf','rg'],required=True)
    p.add_argument('--input',required=True);p.add_argument('--output',required=True)
    p.add_argument('--begin-ps');p.add_argument('--end-ps')
    a=p.parse_args()
    try: result=export(a.input,a.output,a.metric,a.begin_ps,a.end_ps)
    except (ValueError,OSError) as error: p.exit(2,str(error)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__': main()
