"""Export native gmx hbond -num XVG to two-column Origin CSV; no resampling."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
from collections import Counter


def export(source, output):
    source, output = Path(source).resolve(), Path(output).resolve()
    report = output.with_name(output.stem + "-csv.json")
    summary = output.with_name("summary.csv")
    if any(p.exists() for p in (output, report, summary)):
        raise ValueError("输出已存在，请核对来源或先备份")
    raw = source.read_bytes()
    legends, rows, unit = {}, [], None
    for line in raw.decode("utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("@"):
            m = re.search(r'@\s*s(\d+)\s+legend\s+"([^"]+)"', line)
            if m:
                legends[int(m[1])] = m[2]
            m = re.search(r'xaxis\s+label\s+"Time\s*\((ps|ns)\)"', line, re.I)
            if m:
                unit = m[1].lower()
            continue
        if line.startswith("&"):
            raise ValueError("不支持多数据块 XVG")
        row = [float(v) for v in line.split()]
        if len(row) < 2 or any(not math.isfinite(v) for v in row):
            raise ValueError("XVG 列数不足或含非有限值")
        rows.append(row)
    matches = [i + 1 for i, label in legends.items()
               if re.fullmatch(r"hydrogen[ -]*bonds?", label.strip(), re.I)]
    if len(matches) != 1:
        raise ValueError("无法唯一识别 Hydrogen bonds 列；请检查实际图例，勿误用距离内配对数")
    col = matches[0]
    if unit is None or len(rows) < 2 or any(len(r) != len(rows[0]) or len(r) <= col for r in rows):
        raise ValueError("缺少明确的 ps/ns 时间单位、有效采样点或一致的数据列")
    factor = 0.001 if unit == "ps" else 1.0
    times = [r[0] * factor for r in rows]
    if any(b <= a for a, b in zip(times, times[1:])):
        raise ValueError("时间必须严格递增")
    counts = [r[col] for r in rows]
    if any(v < 0 or not v.is_integer() for v in counts):
        raise ValueError("原始氢键数应为非负整数")
    counts = [int(v) for v in counts]
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["time_ns", "hbond_count"])
        writer.writerows(zip(times, counts))
    with output.open(encoding="utf-8", newline="") as stream:
        check = list(csv.DictReader(stream))
    if [(float(r["time_ns"]), int(r["hbond_count"])) for r in check] != list(zip(times, counts)):
        raise RuntimeError("CSV 回读不一致")
    freq = Counter(counts)
    with summary.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["hbond_count", "sampled_frames", "fraction_of_sampled_frames"])
        writer.writerows((c, n, n / len(counts)) for c, n in sorted(freq.items()))
    result = {"status": "passed", "source": str(source),
              "source_sha256": hashlib.sha256(raw).hexdigest(), "legends": legends,
              "selected_numeric_column_1based": col + 1, "source_time_unit": unit,
              "csv": str(output), "csv_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
              "rows": len(rows), "time_ns": [times[0], times[-1]],
              "count_min": min(counts), "count_max": max(counts),
              "framewise_mean": statistics.mean(counts), "framewise_median": statistics.median(counts),
              "fraction_of_sampled_frames_with_any_hbond": sum(v > 0 for v in counts) / len(counts),
              "sampling_intervals_ns": sorted(set(round(b-a, 12) for a, b in zip(times, times[1:]))),
              "resampled": False, "csv_roundtrip_equal": True,
              "scope": "Aggregate counts per saved frame; fractions are sampled-frame fractions, not per-bond occupancy or independent replicates."}
    report.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source")
    parser.add_argument("output")
    args = parser.parse_args()
    print(json.dumps(export(args.source, args.output), ensure_ascii=False, indent=2))
