"""Summarize native VMD residue-pair presence, without substituting COM distances."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path


def summarize(directory, system_label):
    root = Path(directory).resolve()
    if not system_label.strip() or system_label == 'Salt bridge':
        raise ValueError('Invalid system label')
    if (root/'saltbridge.csv').exists() or (root/'occupancy.csv').exists():
        raise ValueError('Output exists; verify or back up first')
    check = dict(line.split('=', 1) for line in (root/'vmd-check.txt').read_text().splitlines() if '=' in line)
    if check.get('status') != 'PASSED':
        raise ValueError('VMD native calculation has not passed')
    nframes = int(check['trajectory_frames'])
    cutoff = float(check['cutoff_A'])
    with (root/'pairs.tsv').open(newline='', encoding='utf-8') as stream:
        pairs = list(csv.DictReader(stream, delimiter='\t'))
    by_id = {r['pair_id']: r for r in pairs}
    if len(by_id) != len(pairs) or len(pairs) != int(check['native_pairs']):
        raise ValueError('Duplicate pair IDs or inconsistent native count')
    data = {key: {} for key in by_id}
    times = {}
    with (root/'frames.csv').open(newline='', encoding='utf-8') as stream:
        for row in csv.DictReader(stream):
            key, i = row['pair_id'], int(row['sample_index'])
            time, distance = float(row['time_ps']), float(row['min_on_A'])
            if key not in data or i in data[key] or not 0 <= i < nframes:
                raise ValueError('Unknown pair, duplicate or invalid sample')
            if row['present'] not in ('0', '1') or not math.isfinite(time) or not math.isfinite(distance) or distance < 0:
                raise ValueError('Invalid presence, time or distance')
            present = int(row['present'])
            if present and distance > cutoff+1e-5:
                raise ValueError('Presence inconsistent with O-N distance')
            if i in times and times[i] != time:
                raise ValueError('Inconsistent sample times')
            times[i] = time
            data[key][i] = present
    expected = set(range(nframes))
    if any(set(values) != expected for values in data.values()):
        raise ValueError('Missing frames; cannot replace missing observations with zero')
    if pairs and (set(times) != expected or any(times[i] >= times[i+1] for i in range(nframes-1))):
        raise ValueError('Invalid time order or coverage')
    def residue_label(row, prefix):
        chain, seg = row[prefix+'chain'], row[prefix+'segname']
        stem = row[prefix+'resname'] + row[prefix+'resid']
        return (chain+':' if chain else '') + stem + ('@'+seg if seg else '')
    results = []
    for row in pairs:
        key = row['pair_id']
        label = residue_label(row, 'acid_')+'-'+residue_label(row, 'base_')
        hits = sum(data[key].values())
        results.append({'pair_id':key, 'Salt bridge':label, 'formed_frames':hits,
                        'analyzed_frames':nframes, 'occupancy':hits/nframes})
    results.sort(key=lambda row: (-row['occupancy'], row['Salt bridge'], row['pair_id']))
    labels = [row['Salt bridge'] for row in results]
    if len(set(labels)) != len(labels):
        raise ValueError('Ambiguous chain/residue labels; provide unique structural mapping')
    with (root/'occupancy.csv').open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=['pair_id','Salt bridge','formed_frames','analyzed_frames','occupancy'])
        writer.writeheader(); writer.writerows(results)
    with (root/'saltbridge.csv').open('w', encoding='utf-8', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(['Salt bridge',system_label])
        writer.writerows((r['Salt bridge'],r['occupancy']) for r in results)
    with (root/'saltbridge.csv').open(encoding='utf-8', newline='') as stream:
        saved = list(csv.reader(stream))
    if saved[1:] != [[r['Salt bridge'],str(r['occupancy'])] for r in results]:
        raise RuntimeError('CSV roundtrip mismatch')
    report = {'status':'passed','pairs':len(results),'frames':nframes,'system_label':system_label,
              'time_ps':[times[0],times[nframes-1]] if times else None,
              'occupancy_definition':'number of sampled frames with native VMD O-N contact / all analyzed trajectory frames',
              'row_order':'occupancy descending, then residue label',
              'replicate_mean_computed':False,'resampled':False,
              'sha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['pairs.tsv','frames.csv','occupancy.csv','saltbridge.csv']}}
    (root/'csv-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory'); parser.add_argument('--label', required=True)
    args = parser.parse_args()
    print(json.dumps(summarize(args.directory,args.label),ensure_ascii=False,indent=2))
