# Source after setting project variables in an owned VMD text-mode instance.
# All geometry and candidate identification are performed by native VMD.
proc sb_run {} {
    global structure trajectory output_dir protein_indices acid_indices base_indices cutoff times expected_atoms
    if {$cutoff <= 0 || [llength $times] < 1} {error "Invalid cutoff or trajectory times"}
    foreach filename {pairs.tsv frames.csv vmd-check.txt} {
        if {[file exists [file join $output_dir $filename]]} {error "Output exists: $filename; verify or back up first"}
    }
    set member [dict create]
    foreach i $protein_indices {dict set member $i 1}
    set negative [dict create]
    foreach i $acid_indices {
        if {![dict exists $member $i]} {error "Acid selection is outside enzyme"}
        dict set negative $i 1
    }
    foreach i $base_indices {
        if {![dict exists $member $i] || [dict exists $negative $i]} {error "Base selection outside enzyme or overlapping acid selection"}
    }
    package require saltbr
    set mid [mol new $structure type gro waitfor all]
    set structural_frames [molinfo $mid get numframes]
    mol addfile $trajectory type xtc waitfor all molid $mid
    if {[molinfo $mid get numatoms] != $expected_atoms || [molinfo $mid get numframes] != $structural_frames+[llength $times]} {error "Structure/trajectory atom or frame count mismatch"}
    set whole [atomselect $mid "index $protein_indices"]
    if {[$whole num] != [llength $protein_indices]} {error "Protein selection mismatch"}
    set charged_missing [atomselect $mid "(index $acid_indices $base_indices) and not protein"]
    if {[$charged_missing num] != 0} {error "VMD protein keyword omits charge-qualified residues; adapt residue recognition first"}
    $charged_missing delete
    set unrecognized [atomselect $mid "([$whole text]) and not protein"]
    set omitted_neutral_atoms [$unrecognized num]
    $unrecognized delete
    # Charge-qualified residue membership is supplied after topology review.
    # Macros change only in this disposable VMD instance; no installation edits.
    atomselect macro acidic "index $acid_indices"
    atomselect macro basic "index $base_indices"
    set acid [atomselect $mid "([$whole text]) and acidic and oxygen and not backbone"]
    set base [atomselect $mid "([$whole text]) and basic and nitrogen and not backbone"]
    if {[$acid num] == 0 || [$base num] == 0} {error "No qualified acidic O or basic N atoms"}
    set first $structural_frames
    set last [expr {[molinfo $mid get numframes]-1}]
    file mkdir [file join $output_dir native]
    set native_count [::saltbr::saltbr -sel $whole -frames "$first:1:$last" -ondist $cutoff -comdist none -upsel no -writefiles yes -outdir [file join $output_dir native] -log saltbr.log]
    foreach row [$whole get {index residue resid resname chain segname}] {
        lassign $row i r resid resname chain segname
        set atom_res($i) $r
        set meta($r) [list $resid $resname $chain $segname]
    }
    foreach i [$acid get index] {lappend acid_atoms($atom_res($i)) $i}
    foreach i [$base get index] {lappend base_atoms($atom_res($i)) $i}
    array set observed {}
    array set presence {}
    for {set sample 0} {$sample < [llength $times]} {incr sample} {
        set frame [expr {$structural_frames+$sample}]
        $acid frame $frame
        $base frame $frame
        set contact [measure contacts $cutoff $acid $base]
        foreach i [lindex $contact 0] j [lindex $contact 1] {
            set key "$atom_res($i),$atom_res($j)"
            set observed($key) 1
            set presence($key,$sample) 1
        }
    }
    if {[array size observed] != $native_count} {error "Native plugin and per-frame contact union disagree"}
    set pf [open [file join $output_dir pairs.tsv] w]
    puts $pf [join {pair_id acid_residue_index acid_resid acid_resname acid_chain acid_segname base_residue_index base_resid base_resname base_chain base_segname} \t]
    set ff [open [file join $output_dir frames.csv] w]
    puts $ff "sample_index,vmd_frame,time_ps,pair_id,min_on_A,present"
    foreach key [lsort -dictionary [array names observed]] {
        lassign [split $key ,] a b
        set id "r${a}_r${b}"
        puts $pf [join [concat [list $id $a] $meta($a) [list $b] $meta($b)] \t]
        for {set sample 0} {$sample < [llength $times]} {incr sample} {
            set frame [expr {$structural_frames+$sample}]
            set minimum Inf
            foreach i $acid_atoms($a) {
                foreach j $base_atoms($b) {
                    set distance [lindex [measure bond [list $i $j] molid $mid frame $frame] 0]
                    if {$distance < $minimum} {set minimum $distance}
                }
            }
            set present [expr {[info exists presence($key,$sample)] ? 1 : 0}]
            # Contact membership is authoritative; min distance is an audit column.
            if {$present && $minimum > $cutoff+1e-5} {error "Presence/distance mismatch"}
            puts $ff "$sample,$frame,[lindex $times $sample],$id,$minimum,$present"
        }
    }
    close $pf
    close $ff
    set log [open [file join $output_dir vmd-check.txt] w]
    puts $log "status=PASSED"
    puts $log "vmd_version=[vmdinfo version]"
    puts $log "saltbr_package=[package present saltbr]"
    puts $log "structural_frames_excluded=$structural_frames"
    puts $log "trajectory_frames=[llength $times]"
    puts $log "protein_atoms=[$whole num]"
    puts $log "neutral_atoms_outside_vmd_protein_keyword=$omitted_neutral_atoms"
    puts $log "acidic_oxygen_atoms=[$acid num]"
    puts $log "basic_nitrogen_atoms=[$base num]"
    puts $log "native_pairs=$native_count"
    puts $log "per_frame_union_pairs=[array size observed]"
    puts $log "cutoff_A=$cutoff"
    close $log
    $acid delete
    $base delete
    $whole delete
}
if {[catch {sb_run} message options]} {
    set error_log [open [file join $output_dir vmd-error.log] w]
    puts $error_log $message
    puts $error_log [dict get $options -errorinfo]
    close $error_log
    puts "SALTBRIDGE_FAILED: $message"
    quit
} else {
    puts "SALTBRIDGE_PASSED"
    quit
}
