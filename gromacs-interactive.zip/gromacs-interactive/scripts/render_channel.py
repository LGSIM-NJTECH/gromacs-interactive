#!/usr/bin/env python3
"""Render verified protein/ligand and native channel spheres with headless PyMOL.

Run with the Python interpreter belonging to an installed PyMOL environment.
All project paths and PDB serial selections come from --config, never this skill.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys
import traceback


DEFAULT_STYLE = {
    "protein_rgb": [0.25, 0.43, 0.56],
    "surface_rgb": [0.76, 0.80, 0.82],
    "channel_rgb": [1.0, 0.77, 0.0],
    "ligand_rgb": [0.93, 0.39, 0.05],
    "surface_transparency": 0.78,
    "stick_radius": 0.18,
    "camera_turn_y": 20.0,
    "width": 1800,
    "height": 1600,
    "dpi": 300,
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def pdb_atoms(path):
    lines = path.read_text(encoding="utf-8-sig").splitlines()
    require(sum(s.startswith("MODEL") for s in lines) <= 1,
            "Select a single structure/channel state before rendering: " + str(path))
    atoms = []
    for s in lines:
        if not s.startswith(("ATOM  ", "HETATM")):
            continue
        xyz = [float(s[a:b]) for a, b in [(30, 38), (38, 46), (46, 54)]]
        require(all(math.isfinite(v) for v in xyz), "Nonfinite PDB coordinates")
        atoms.append({"serial": int(s[6:11]), "xyz": xyz,
                      "beta": s[60:66].strip(), "identity": s[12:27]})
    require(bool(atoms), "PDB has no atoms: " + str(path))
    require(len({a["serial"] for a in atoms}) == len(atoms),
            "PDB serial numbers must be unique; resolve mapping first: " + str(path))
    return atoms


def resolve_config(config_path, prefix, *, check_only=False):
    config_path = config_path.resolve()
    data = json.loads(config_path.read_text(encoding="utf-8-sig"))
    def resolve(value):
        p = Path(value).expanduser()
        return (config_path.parent / p).resolve() if not p.is_absolute() else p.resolve()
    require(re.fullmatch(r"[A-Za-z0-9_-]+", prefix) is not None, "Invalid output prefix")
    structure = resolve(data["structure"])
    atoms = pdb_atoms(structure)
    def atom_ids(key):
        values = data.get(key, [])
        require(isinstance(values, list) and all(type(v) is int and v > 0 for v in values),
                key + " must contain positive PDB serial integers")
        require(len(values) == len(set(values)), "Duplicate selection IDs in " + key)
        return values
    protein = atom_ids("protein_atom_ids")
    ligand = atom_ids("ligand_atom_ids")
    require(bool(protein), "Explicit protein_atom_ids are required")
    require(not set(protein).intersection(ligand), "Protein and ligand selections overlap")
    require(set(protein + ligand) == {a["serial"] for a in atoms},
            "Selections must cover the verified protein/ligand structure exactly; "
            "prepare the intended complex first, without silently hiding other components")
    require(data.get("radius_field") == "b" and data.get("radius_unit") == "angstrom"
            and data.get("radius_semantics_verified") is True,
            "Confirm native PDB beta is sphere radius in Angstrom before rendering")
    channels = []
    for item in data.get("channels", []):
        path = resolve(item["pdb"])
        points = pdb_atoms(path)
        radii = [float(a["beta"]) for a in points]
        require(all(math.isfinite(v) and v > 0 for v in radii), "Invalid channel radii")
        channels.append({"id": str(item["id"]), "path": path,
                         "points": points, "radii": radii})
    require(bool(channels), "Choose at least one verified channel")
    require(len({a["id"] for a in channels}) == len(channels), "Duplicate channel labels")
    style = dict(DEFAULT_STYLE)
    overrides = data.get("style", {})
    require(not (set(overrides) - set(style)), "Unknown style setting")
    style.update(overrides)
    for name in ["protein_rgb", "surface_rgb", "channel_rgb", "ligand_rgb"]:
        rgb = style[name]
        require(isinstance(rgb, list) and len(rgb) == 3
                and all(isinstance(x, (int, float)) and math.isfinite(x) and 0 <= x <= 1 for x in rgb),
                "Invalid RGB color: " + name)
    require(0 <= style["surface_transparency"] <= 1, "Invalid surface transparency")
    require(math.isfinite(style["stick_radius"]) and style["stick_radius"] > 0, "Invalid stick radius")
    require(math.isfinite(style["camera_turn_y"]), "Invalid camera turn")
    for name in ["width", "height", "dpi"]:
        require(type(style[name]) is int and style[name] > 0, "Invalid " + name)
    output = resolve(data.get("output_dir", "."))
    require(output.is_dir(), "Create the project module directory first")
    paths = {"png": output / (prefix + ".png"), "pse": output / (prefix + ".pse"),
             "report": output / (prefix + "-render.json")}
    if not check_only:
        require(not any(q.exists() for q in paths.values()),
                "Outputs already exist; reuse verified results or back them up before rerendering")
    reference = Path(__file__).resolve().parents[1] / "assets" / "channel-reference.png"
    hashes = {str(q): sha(q) for q in [config_path, structure] + [x["path"] for x in channels]}
    if reference.is_file():
        hashes[str(reference)] = sha(reference)
    for name, expected in data.get("source_sha256", {}).items():
        require(sha(resolve(name)) == expected, "Confirmed source hash changed: " + name)
    return {"structure": structure, "protein": protein, "ligand": ligand,
            "channels": channels, "style": style, "outputs": paths,
            "reference": reference, "hashes": hashes}


def render(spec):
    import numpy as np
    import pymol2
    style, paths = spec["style"], spec["outputs"]
    pm = pymol2.PyMOL()
    pm.invocation.options.external_gui = 0
    pm.invocation.options.internal_gui = 0
    pm.invocation.options.no_gui = 1
    pm.start()
    c = pm.cmd
    def sig(name):
        m = c.get_model(name, state=1)
        colors = []
        c.iterate(name, "colors.append(color)", space={"colors": colors})
        return {"atoms": len(m.atom), "states": c.count_states(name), "colors": colors,
                "identity": [(a.id, a.name, a.resn, a.resi, a.chain, a.symbol) for a in m.atom],
                "xyz": np.array([a.coord for a in m.atom]),
                "vdw": np.array([a.vdw for a in m.atom]), "beta": np.array([a.b for a in m.atom])}
    try:
        c.set("retain_order", 1)
        c.load(str(spec["structure"]), "source_structure")
        c.create("enzyme", "source_structure and id " + "+".join(map(str, spec["protein"])))
        require(c.count_atoms("enzyme") == len(spec["protein"]), "Incomplete protein selection")
        objects = ["source_structure", "enzyme"]
        visible = ["enzyme"]
        if spec["ligand"]:
            c.create("substrate", "source_structure and id " + "+".join(map(str, spec["ligand"])))
            require(c.count_atoms("substrate") == len(spec["ligand"]), "Incomplete ligand selection")
            objects.append("substrate")
            visible.append("substrate")
        for i, ch in enumerate(spec["channels"]):
            name = "channel" if len(spec["channels"]) == 1 else "channel_" + str(i + 1)
            ch["object"] = name
            c.load(str(ch["path"]), name)
            c.alter(name, "vdw=b")
            c.rebuild(name)
            model = c.get_model(name)
            require(len(model.atom) == len(ch["points"]) and c.count_states(name) == 1,
                    "Channel point/state mismatch")
            require(np.max(abs(c.get_coords(name) - np.array([a["xyz"] for a in ch["points"]]))) < 1e-5,
                    "Channel coordinates changed")
            require(np.max(abs(np.array([a.vdw for a in model.atom]) - ch["radii"])) < 1e-5,
                    "Channel radius mapping mismatch")
            objects.append(name)
            visible.append(name)
        c.hide("everything", "all")
        c.disable("source_structure")
        for key in ["protein_rgb", "surface_rgb", "channel_rgb", "ligand_rgb"]:
            c.set_color("template_" + key, style[key])
        c.color("template_protein_rgb", "enzyme")
        c.dss("enzyme")
        c.show("cartoon", "enzyme")
        c.show("surface", "enzyme")
        c.set("surface_color", "template_surface_rgb", "enzyme")
        c.set("transparency", style["surface_transparency"], "enzyme")
        if spec["ligand"]:
            c.color("template_ligand_rgb", "substrate")
            c.show("sticks", "substrate and not hydro")
            c.set("stick_radius", style["stick_radius"], "substrate")
        for ch in spec["channels"]:
            name = ch["object"]
            c.color("template_channel_rgb", name)
            c.show("spheres", name)
            c.set("sphere_scale", 1, name)
            c.set("sphere_transparency", 0, name)
        c.bg_color("white")
        settings = {"orthoscopic": 1, "ray_opaque_background": 1, "ray_trace_mode": 1,
                    "ray_trace_gain": 0.08, "ray_shadows": 0, "depth_cue": 0,
                    "antialias": 2, "ambient": 0.45, "specular": 0.25, "surface_quality": 1,
                    "cartoon_fancy_helices": 1, "cartoon_flat_sheets": 1,
                    "max_threads": min(8, os.cpu_count() or 1)}
        for key, value in settings.items():
            c.set(key, value)
        c.viewport(style["width"], style["height"])
        c.orient("enzyme")
        coords = c.get_coords("enzyme and name CA")
        if coords is None or len(coords) < 3:
            coords = c.get_coords("enzyme")
        points = np.concatenate([c.get_coords(ch["object"]) for ch in spec["channels"]])
        center = coords.mean(axis=0)
        forward = points.mean(axis=0) - center
        if len(coords) >= 3 and np.linalg.norm(forward) > 1e-6:
            forward /= np.linalg.norm(forward)
            _, _, vectors = np.linalg.svd(coords - center, full_matrices=False)
            up = None
            for candidate in list(vectors) + list(np.eye(3)):
                projected = candidate - np.dot(candidate, forward) * forward
                if np.linalg.norm(projected) > 0.1:
                    up = projected / np.linalg.norm(projected)
                    break
            require(up is not None, "Cannot construct a camera frame")
            right = np.cross(up, forward)
            right /= np.linalg.norm(right)
            up = np.cross(forward, right)
            view = list(c.get_view())
            view[:9] = np.array([right, up, forward]).flatten().tolist()
            c.set_view(view)
        c.turn("y", style["camera_turn_y"])
        c.zoom(" or ".join(visible), buffer=3, complete=1)
        c.deselect()
        before = {name: sig(name) for name in objects}
        saved_view = list(c.get_view())
        require(set(c.get_names("objects", enabled_only=1)) == set(visible), "Unexpected visible objects")
        c.save(str(paths["pse"]))
        c.png(str(paths["png"]), width=style["width"], height=style["height"],
              dpi=style["dpi"], ray=1, quiet=0)
        require(paths["png"].stat().st_size > 1000, "Rendered image is missing/empty")
        c.reinitialize()
        c.load(str(paths["pse"]))
        require(set(c.get_names("objects")) == set(objects), "PSE object mismatch")
        require(set(c.get_names("objects", enabled_only=1)) == set(visible), "PSE visibility mismatch")
        for name, old in before.items():
            new = sig(name)
            for key in ["atoms", "states", "identity", "colors"]:
                require(old[key] == new[key], "PSE readback mismatch: " + name + "/" + key)
            require(new["states"] == 1, "Expected a single state")
            for key in ["xyz", "vdw", "beta"]:
                require(np.max(abs(old[key] - new[key])) < 1e-5, "PSE geometry mismatch: " + name + "/" + key)
        for ch in spec["channels"]:
            name = ch["object"]
            require(abs(c.get_setting_float("sphere_scale", name) - 1) < 1e-5,
                    "PSE sphere scale changed")
            require(abs(c.get_setting_float("sphere_transparency", name)) < 1e-5,
                    "PSE sphere transparency changed")
        require(abs(c.get_setting_float("transparency", "enzyme") - style["surface_transparency"]) < 1e-5,
                "PSE protein transparency changed")
        require(max(abs(a - b) for a, b in zip(saved_view, c.get_view())) < 1e-5, "PSE camera changed")
        for key in ["protein_rgb", "surface_rgb", "channel_rgb", "ligand_rgb"]:
            require(max(abs(a - b) for a, b in zip(c.get_color_tuple("template_" + key), style[key])) < 1e-5,
                    "PSE palette changed")
        require(all(sha(Path(name)) == digest for name, digest in spec["hashes"].items()),
                "An input changed while rendering")
        report = {"status": "passed_native_readback", "visual_QA": "pending_agent_image_inspection",
                  "pymol_version": list(c.get_version()), "style": style, "settings": settings,
                  "reference": str(spec["reference"]), "source_hashes": spec["hashes"],
                  "object_atoms": {name: before[name]["atoms"] for name in objects},
                  "object_states": {name: before[name]["states"] for name in objects},
                  "visible_objects": visible, "source_structure_hidden_and_disabled": True,
                  "channels": [{"id": ch["id"], "object": ch["object"], "source": str(ch["path"]),
                                "points": len(ch["points"])} for ch in spec["channels"]],
                  "radius_mapping": "native PDB beta -> vdw, Angstrom, sphere_scale=1",
                  "coordinates_and_radii_preserved": True, "session_readback": "passed",
                  "camera_view": saved_view, "labels": False,
                  "outputs": {k: {"path": str(paths[k]), "sha256": sha(paths[k])} for k in ["png", "pse"]}}
        paths["report"].write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return report
    finally:
        pm.stop()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--prefix", default="channel")
    parser.add_argument("--check-only", action="store_true", help="Validate inputs without importing PyMOL or writing outputs")
    args = parser.parse_args()
    try:
        spec = resolve_config(args.config, args.prefix, check_only=args.check_only)
        if args.check_only:
            print(json.dumps({"status": "inputs_validated", "protein_atoms": len(spec["protein"]),
                              "ligand_atoms": len(spec["ligand"]), "channels": len(spec["channels"])}, ensure_ascii=False))
        else:
            report = render(spec)
            print(json.dumps({"status": report["status"], "visual_QA": report["visual_QA"],
                              "report": str(spec["outputs"]["report"])}, ensure_ascii=False))
        return 0
    except Exception:
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
