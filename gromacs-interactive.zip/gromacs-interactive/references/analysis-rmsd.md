# 骨架 RMSD → CSV → Origin

对应用户命令：`echo 4 4 | gmx rms -s md.tpr -f md_noPBC.xtc -o rmsd.xvg`。

先完成 analysis-pbc.md 的 PBC 处理并核对匹配 TPR。每个体系读取真实菜单，将用户的骨架拟合/计算定义映射到实际组名和原子数；不固定组号 4，也不改成 Cα 或整个蛋白。持久终端分别输入拟合组和计算组，保留菜单、选择、版本、退出码。参考为对应 TPR 中结构，质量加权记录当前版本实际默认值。

核对输出 `rmsd.xvg` 的非空、有限数值、单位、行数和真实时间范围。由 XVG 导出 `rmsd.csv`；来源为 ps/nm 时使用列 `time_ns,rmsd_nm`，只将时间除以 1000，RMSD 数值不改。其他单位先核对转换，不凭数字大小猜测。禁止静默插值、筛掉异常值或用平滑值替代原数据。

随后进入 [CSV→Origin](origin-csv.md)，每次询问图型、模板和平滑设置。单轨迹只能表达该轨迹，不能虚构平行间误差带；RMSD 不能直接等同催化性能或结合自由能。

运行记录与核验结果保存在当前项目。后续按用户授权分别进入 [RMSF](analysis-rmsf.md) 或 [Rg](analysis-rg.md)，不自动计算其他指标。
