# 氢键：交互建组、原生计算、CSV 与 Origin

本模块属于同一个 skill；结果放在实际 `MD_ROOT/hbond`。只复用方法，重新识别当前体系、版本和选区，不把上次的组号、残基、时间或阈值当作新体系默认值。

## 计算前的中文选择

读取匹配的 `md.tpr`、`md.gro` 与已核验的 `md_noPBC.xtc`（可位于 `rmsd-Rg-RMSF`），保留含氢的原子顺序和拓扑连接。不要将口袋伪原子 PDB、纯酶截图用结构或不匹配的去溶剂轨迹输入全体系 TPR。

在建组前弹出中文选项：①完整酶与指定底物；②活性位点与突变位点；③自定义链、残基或原子选区。多链、多底物时明确具体分子；编号须与真实链、残基名和结构映射核对。只知道残基号时不能擅自判为催化三联体。

另确认实际有效时间区间、采样方式及图型、模板、平滑；已确认设置沿用。提供原始折线、散点连线，独立重复存在时才提供明确统计含义的误差带。可让用户提供参考图片。整数 ns 的示例表只是排版，不能据此删掉其他帧、四舍五入时间或制造采样点。

## 建组与版本分支

在模块目录执行用户原命令，读取真实菜单再回应：

```text
gmx make_ndx -f ../md.gro -o hbond_index.ndx
gmx hbond -s ../md.tpr -f ../rmsd-Rg-RMSF/md_noPBC.xtc -num hbnum.xvg -n hbond_index.ndx
```

路径只是标准布局示意，以实际匹配文件为准。选择现有组或按用户选区新建 `Enzyme`、`Substrate` 等清楚名称，保留原始 `index.ndx`。执行前检查两组非空、无重复原子、编号在 TPR 范围内、覆盖所选分子且含计算需要的氢；两组须完全相同或不重叠。部分重叠时解释并让用户选择定义，不能静默减去交集。记录命令、菜单、最终组名、实际编号和原子数。

先读取 `gmx --version` 与 `gmx hbond -h`。旧版（例如 2020 系列）默认 D–A 距离 0.35 nm、H–D–A 角 30°（0°伸直）、N 可为受体、多个氢的原生合并规则；必须展示当前实际默认值，让用户选择沿用或自定义。距离定义 `-da`、角度 `-a`、`-nitacc`、`-merge` 以当前帮助为准，`-contact` 不是氢键计算。不要默认所有 N 的化学受体性质都准确。

2024 起新版 `hbond` 的选择语法、参数含义不同，例如 `-r` 是参考选区，不能把旧版距离参数 `-r 0.35` 直接传给新版。按实际帮助使用新版，或在用户同意后使用可用的 `hbond-legacy` 并记录；两种实现不能未经核对直接混合比较。[旧版文档](https://manual.gromacs.org/documentation/2020/onlinehelp/gmx-hbond.html)、[当前文档](https://manual.gromacs.org/current/onlinehelp/gmx-hbond.html)。

用户指定窗口时增加经核实单位的 `-b BEGIN -e END`；保留所有采样点时不加抽帧参数。氢键计数使用 CPU，不需要重新运行 MD。失败时按组重叠、无供受体、拓扑/氢缺失、原子不匹配、版本语法、真实时间范围逐项定位；零氢键本身是有效结果，不能通过放宽阈值制造非零。

## XVG 整理和汇总

保留 `hbnum.xvg`。检查 `@ sN legend`，旧版常有“Hydrogen bonds”和“Pairs within …”两列，后者不是氢键数。使用实际氢键列，保留时间及非负整数计数；缺失值不能填成零。导出：

```text
python scripts/hbond_csv.py MD_ROOT/hbond/hbnum.xvg MD_ROOT/hbond/hbnum.csv
```

该脚本按明确的 Hydrogen bonds 图例识别计数，ps→ns，输出两列 `time_ns,hbond_count`，不平滑、不重采样。模糊图例或不支持的新版输出先检查实际格式，再适配；不猜列。`hbnum-csv.json` 记录来源哈希、列、单位、点数、范围、帧均值/中位数；`summary.csv` 为计数分布与采样帧比例。等间隔采样下可报告至少一条氢键的采样帧占比；不称为某一特定氢键的占有率，也不能把相关帧当作独立重复。逐键占有率、寿命或供受体身份需额外原生输出并单独授权分析。

## Origin 绘图与验收

按 [origin-csv.md](origin-csv.md) 使用原生 Origin 读取两列 CSV，A 为 X，Long Name=`Time`、Units=`ns`；B 为 Y，Long Name=`Number of hydrogen bonds`，无物理单位。原始计数使用 `y_axis_kind: count`、整数刻度；单轨迹无误差带。用户原始样式图为 `../assets/hbond-reference.png`，仅用于参考深蓝、浅灰网格及画幅；实际数据确定横纵范围，白底确保可读。新体系仍询问是否沿用或提供新模板。

`scripts/origin_csv_plot.py` 的作业支持可选 `column_metadata`（列名对应 `long_name`/`units`）、`page_size`（width/height，Origin 页面单位）及 `y_axis_kind: count`。CSV 列保持数值，标签写入 Origin 列标签行，不将表头/单位伪装成数据行。原始折线不插值、不平滑；如用户希望分箱平均，另生成有明确统计含义的副本并区分原始整数计数。

交付 `hbnum.csv`、`hbnum.opju`、`hbnum.png` 及 `record.json`。原生工程重新打开后逐值比较 CSV、验证列标签和曲线绑定；检查图片坐标、整数刻度、线型、网格和实际范围。退出码成功不等于通过。项目记录保留用户答案、输入哈希、两组定义、版本/判据、实际时间范围、结果和修复记录；验证结果不写入 skill。
