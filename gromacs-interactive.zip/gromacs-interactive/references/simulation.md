# 准备、执行与用户选择

## 起点

只检查用户指定目录，识别 PDB/GRO、SDF/MOL2、ITP/TOP、MDP、检查点/轨迹。检查 GROMACS 的实际可执行路径、版本、CPU/GPU 环境与工作目录权限。用户未选择运行资源时提问；调度服务器以分配资源为上限，不用 unset 环境变量“获取权限”。

可以执行 `gmx_files.py inspect --directory ...` 取得只读摘要。包含路径、相对 TOP 的局部依赖存在性、GRO 原子信息、PDB 模型与链、MDP 设置。报告缺项不等于一概阻止：缺总 TOP 对初始建模可能正常；缺配体参数则不能用 pdb2gmx 假定补齐。

## 基础步骤

以下是可适配的命令形状，文件名和选项来自本次项目。先读匹配版本 `gmx help`/官方文档，不能盲目拷贝其他版本或体系。

1. `pdb2gmx -f protein.pdb -o protein.gro -p topol.top -ignh`：展示实际力场/水模型菜单，等待中文选择。`-missing` 不自动补缺失重原子，默认不带；末端、组氨酸、二硫键等需按实际模型明确处理。
2. 配体/辅因子：确认化学身份、立体化学、质子化、电荷和兼容参数；坐标与 ITP 的原子名和顺序核对。保留已对接的相对位置。合并坐标/拓扑时不得丢失分子，不重新随机放置已结合配体。
3. `editconf -f complex.gro -o boxed.gro ...`：让用户选择盒型和距离/尺寸；膜等特殊体系使用相应的构建器和盒子方案。
4. 添加溶剂：先选组分，再输入数量模式与数值。水可用 solvate；自定义溶剂根据模型用溶剂盒、insert-molecules 或 Packmol。盒子装填方法随体系而定；用户数量不能用“最大装满”自行代替。预先保存 TOP，solvate 若已更新则只核对，避免重复计数。
5. `grompp -f ions.mdp ...` 后核实总电荷。让用户选择离子种类、中和/数量/浓度与替换组；随后调用 genion 或适合该体系的插入方式。不要自动把 DES 组分当作可牺牲的水。同步实际 TOP；原子数与模板一致后继续。
6. `grompp -f em.mdp ...`，成功且警告经处理后只启动一次 `mdrun -deffnm em ...`。核对最终最大力、收敛条件与异常；退出正常但未满足当前 EM 标准不能直接标为收敛。需要二次 EM 时读实际 em2.mdp。
7. `make_ndx` 建立 MDP 真正需要的组；按名称/原子清单核对，标准默认组已足够时不为形式额外建组。
8. 平衡阶段由 MDP 内容和物理体系确定，可能 NVT→NPT 或多个阶段。存在位置限制时核对 `-r` 与受限原子；gen-vel、continuation、约束和压力耦合必须相容。不能仅因名称是 pr 就假定已充分平衡。
9. 正式 MD 可从相容的平衡 `gro/cpt` 生成新阶段 TPR。MD 中断恢复与阶段转换是不同动作：恢复同一任务通常 `mdrun -deffnm md -cpi md.cpt`，先检查版本、TPR/检查点与输出文件关系；保留原速度/状态，不在续跑时擅自 gen-vel。

## 运行与状态

普通、指定资源、后台、调度提交是替代运行方式，不是连续执行的多条 mdrun。先查同一项目是否已有运行，避免同一输出前缀启动两次。

Linux 用 `#` 注释，`nohup ... > stdout.log 2>&1 &` 是一种后台方式，不能把 `//`、`&*` 原样执行。Windows 用适合当前 PowerShell/CMD 的语法。GPU update 是否支持需实测；固定 pin offset/stride 或线程数不可跨机器照搬。

记录启动命令、工作目录、程序版本、PID/作业号、标准输出/错误、阶段文件和返回码。运行中的进度从日志读取，不虚报完成；估时用实际 ns/day 并标明不确定性。安全停止依程序/调度器支持的方法保存检查点。

状态至少区分：等待选择、检查中、运行中、完成待检查、通过、需修复、已停止。异步问题未回答时不能推进依赖阶段。

## 参考

优先本地对应版本帮助与官方文档：
- https://manual.gromacs.org/current/onlinehelp/gmx-pdb2gmx.html
- https://manual.gromacs.org/current/onlinehelp/gmx-grompp.html
- https://manual.gromacs.org/current/onlinehelp/gmx-genion.html
- https://manual.gromacs.org/current/user-guide/managing-simulations.html
