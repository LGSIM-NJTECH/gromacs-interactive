# FEL：只使用用户提供的脚本与 PPT 流程

用户已明确要求 FEL 只用其提供的脚本，该要求优先于此前添加的替代工具。原件位于 `../assets/fel-originals/`，解读见 [fel-source-review.md](fel-source-review.md)。本模块仍属于同一个 gromacs-interactive skill。

## 工具边界

- FEL 自定义脚本只用用户的 xpm2all-2.bsh、xpm2png.py，或同哈希原件。GROMACS 命令、文本编辑、Excel/Origin 原有功能完成 PPT 中的相应步骤。
- 不调用已撤下的替代工具，不再编写或引入新的 FEL 计算、合并、转换、最低构象查找或绘图脚本来替换用户脚本。此限制针对 FEL，其他已有模块保持原实现。
- 原脚本出错时说明具体位置、原因、影响和可选办法；提供沿用原用法、调整输入/参数、经用户选择修改原脚本副本等选项。等待用户决定，不擅自改原件或切换工具。
- PPT 提及的 FEL.py、min_protein.tcl 没有提供完整文件；到需要它们的步骤再请用户提供，不根据截图补造。前面已有脚本能做的阶段可正常进行。
- 用户现已追加授权后台 VMD 原生选帧与 PDB 导出，并要求整合为 [选取能量最低点](energy-minimum.md)。此原生操作不受等待历史 FEL.py/min_protein.tcl 原件的限制；不改写前面 FEL 计算/转换脚本，也不冒充这两个历史脚本。

## 逐步询问

沿用已明确的回答；其余用中文选项/数值输入确认输入体系、匹配 TPR/PBC 轨迹、时间区间、真实组菜单、RMSD 参考及拟合/计算组、Rg 组、温度 K、色阶/网格、图型、沿用 PPT 或自定义模板、插值/平滑及构象输出选择。PPT 的 180–200 ns、303.15 K、100 色阶不是本次自动选择。开发此模块不等于授权运行真实 FEL。

## 方法定义与计算口径

蛋白体系按用户确认的定义，以相同帧的骨架 RMSD 和总体 Rg 为两个反应坐标。其他体系或研究问题先让用户确认有意义的原子组/坐标定义，重新检查其可比性，不能只替换组号和标题。使用选定区间的二维直方图，普通等权、无偏采样下按 `ΔG(x,y) = -RT ln[P(x,y)/Pmax]` 理解相对投影自由能；`R=0.008314462618 kJ/(mol·K)`，T 为已确认的 Kelvin 温度。数值估计由用户 PPT 中的 **GROMACS SHAM** 完成，不另外实现公式替代它。

- 概率最高的采样箱归零；同一箱可对应多帧，箱的自由能不是每帧势能。零概率箱不具有可直接解释的有限自由能，其 XPM 高值可能只是显示封顶。
- RMSD 的参考、拟合组、测量组和质量加权，以及 Rg 组/质量定义必须记录。RMSF 的横轴是残基，不能与逐时间点 RMSD 按行拼成此 FEL。
- 时间单位为 ps，RMSD/Rg 为 nm，SHAM 输出相对自由能为 kJ/mol。图中 X/Y 必须按 out.xvg 两坐标的真实顺序标注，不按默认 PC1/PC2 标签猜测。
- 所选帧等权不等于彼此独立。非均匀取样、未平衡区间、多温度或偏置采样须先说明权重/适用性问题并让用户选择处理，不能直接当标准平衡 FEL。
- 对比不同体系前核对坐标、参考、对应原子、区间、温度、分箱和色标；各图分别归零不能直接解释为体系间绝对自由能差。短轨迹能出图不证明收敛。

## 命令与执行顺序

只在本次新建的分析目录中依次执行，先选择、再替换参数、最后运行。开发/整合说明时不自动重跑；任何已存在的输出用新目录区分。

| 阶段 | 工具/动作 | 必须核对的输出 |
|---|---|---|
| 输入与 PBC | gmx check、必要时按原命令 trjconv | 匹配 TPR、完整时间/原子顺序及 md_noPBC.xtc |
| 两坐标 | gmx rms、gmx gyrate，实际 Backbone 菜单 | rmsd-fel.xvg、rg-fel.xvg |
| 数据整理 | 文本编辑/Excel 原有功能，PPT 的 paste 可选 | 三列 out.xvg，逐行时间相同 |
| FEL | gmx sham | gibbs.xpm、gibbs.log、bindex.ndx 等实际文件 |
| 导出 | 用户原 xpm2all-2.bsh 默认用法 | 同主名 gibbs.xyz，禁止重复追加 |
| CSV | Excel 分列、删除空白分隔并另存 CSV | gibbs.csv 与 XYZ 原数值一致 |
| 绘图 | 用户选择的 Origin 原生二维/三维或原 xpm2png.py 路径 | 对应图片、原生工程与检查记录 |
| 选取能量最低点（按授权） | 日志/索引/时间表核对→用户选帧→后台 VMD 原生导出 | 最低箱→候选样本→真实时间→蛋白＋底物 PDB；详见 energy-minimum.md |

输入检查和用户原 PBC 命令：

```text
gmx check -f md.xtc
gmx trjconv -s md.tpr -f md.xtc -o md_noPBC.xtc -pbc mol -ur compact
gmx check -f md_noPBC.xtc
```

转换时读取当前菜单，用户已确认全体系则选择实际 System 组；未确认时显示中文选项。匹配、完整且已通过检查的 md_noPBC.xtc 可复用，不重复转换。此命令不等于完成非共价复合物跨边界重组，详细核查沿用 [analysis-pbc.md](analysis-pbc.md)。

## 1. RMSD、Rg 与数据合并

在新目录执行，BEGIN_PS/END_PS 替换为用户选择：

```text
gmx rms -s md.tpr -f md_noPBC.xtc -o rmsd-fel.xvg -b BEGIN_PS -e END_PS
gmx gyrate -s md.tpr -f md_noPBC.xtc -o rg-fel.xvg -b BEGIN_PS -e END_PS
```

RMSD 两次选择实际 Backbone（拟合、计算），Rg 一次选择 Backbone，不硬编码组号。检查 ps/nm、起止时间、帧数和逐行时间一致；重用已有数据也要核对参考、组、权重及窗口。

按 PPT 用文本编辑或 Excel 的现有功能在工作副本去掉 #/@ 注释；Rg 保留时间和总体 Rg 两列，去掉三个绕轴列。保留源文件备份，不丢原始数据。可在 Bash 按 PPT 用 `paste rmsd-fel.xvg rg-fel.xvg > out.xvg` 后整理重复时间列；先检查目标不存在以免重定向覆盖。最终三列必须为 `time_ps RMSD_nm Rg_nm`，检查行数、逐行时间、首末时间、数值和单位。不新增合并脚本，不静默取交集、舍弃错位帧或插值；有问题先解释并给用户选项。

Excel 导入要检查前导空格和随时间位数变化的字段宽度；不能将连续空白误当空列。核对整个文件格式后选择原生分隔符或固定宽度导入，固定宽度偏移必须来自当前文件。再用 Excel 公式逐行核对时间。导出标准制表符 TXT 后仅改扩展名为 out.xvg，检查首末行和列数。

可用 Excel 原有功能：将 RMSD 时间/值复制至 A/B，将 Rg 时间/总体值复制至 D/E；在 F 列逐行计算 `=A1-D1`，整段 `SUMSQ(F1:FN)=0` 且两源有效行数一致才允许继续，N 为实际数据行数。将 E 复制至 C，再删除 D/F 等辅助列，导出 A/B/C 为无表头制表符文本。不能仅比较首末时间或相加正负差后认为全部帧匹配。

## 2. SHAM

先读当前 gmx sham -h，保留 PPT 命令结构，温度和色阶按用户选择替换：

```text
gmx sham -tsham T_K -nlevels LEVELS -f out.xvg -ls gibbs.xpm -g gibbs.log -lsh enthalpy.xpm -lss entropy.xpm
```

默认按 -time yes 读取时间列，两坐标不等于 -n 2。-nlevels 是显示量化级数，和 -ngrid 分箱数不同；网格、范围或显式 -bin bindex.ndx 等参数按已确认选择添加。保留实际命令、stdout/stderr、退出码、版本及输出清单。

带网格、箱成员和概率输出的通用模板（各大写项必须来自本次回答或已确认的版本默认）：

```text
gmx sham -tsham T_K -nlevels LEVELS -ngrid NX NY NZ -f out.xvg -ls gibbs.xpm -g gibbs.log -lsh enthalpy.xpm -lss entropy.xpm -bin bindex.ndx -lp prob.xpm
```

使用同哈希的 skill 内嵌原脚本 `assets/fel-originals/xpm2all-2.bsh` 时，解析当前技能安装位置并调用其绝对路径，不依赖某台电脑的盘符。温度来自当前模拟与用户确认，网格按当前采样和选择设置。二维使用 NX/NY，第三个网格参数按当前 SHAM 版本接口填写，不据此把输入解释成三维。

PPT 命令输出 gibbs.xpm，后续截图却用 gibbs13.xpm；按实际输入维数和输出核对，不盲目选后缀/改名。只有 RMSD/Rg 时，即使生成 enthalpy/entropy 文件，也不解释为可信焓熵分解。图是所选坐标和采样窗口上的相对自由能，不据此声称绝对结合自由能或模拟收敛。

## 3. 用户的 xpm2png.py

```text
python PATH/xpm2png.py -f FILE_XPM -o FILE_PNG -ip IP_CHOICE -show SHOW_CHOICE
```

IP_CHOICE/SHOW_CHOICE 为用户选择的 yes/no；PPT 的 yes/yes 分别是双线性显示插值与显示窗口，不自动套用。它输出 Matplotlib PNG，不标为 Origin 工程。截图将 Rg 标成 RMSF，应先说明，在工作 XPM 副本用文本编辑改轴标题为真实 RMSD(nm)/Rg(nm)，不改像素/能量数值，再运行同一个原脚本。

检查方向、坐标、色条和裁切，使用新目录避免覆盖。已识别的非方形 Y 轴校验、坐标截断、刻度偏移和小网格步长问题见逐页解读。触发时报告具体原因并给选项，不能擅自修脚本或切换替代程序，也不能把异常图标成通过。

## 4. 用户的 xpm2all-2.bsh 与 Origin

```text
bash PATH/xpm2all-2.bsh FILE_XPM
```

按 PPT 默认用法导出同主名 XYZ，不额外加 -xyz。本机测试发现原版显式 -xyz 会拼出带尾随空格的错误文件名，默认不加选项可用。检查 Bash/awk 和路径；原版追加写入 .xyz，务必新目录、目标不存在且只执行一次。

按 PPT 将生成的 XYZ 用 Excel 文本导入/分列，另存 gibbs.csv；这只是原输出的格式转换，不重算能量、不补值/平滑/改坐标，不新增转换脚本。核对原 XYZ 与 CSV 的数值、行数、方向和单位。源 XPM 的未采样箱可能是有限高值，不能从颜色推断真实采样；发现解释或显示问题先说明并让用户选择处理方式。

原脚本 XYZ 含 # 表头和网格行间的空白分隔。Excel 从实际第一行数据导入，按当前输出核对三字段边界；只删除三列均空的分隔行，保留全部数值行。坐标确为 RMSD/Rg 时添加 CSV 标题 `rmsd_nm,rg_nm,free_energy_kj_mol`，其他坐标使用真实名称和单位。用 Excel 原有另存 CSV UTF-8 功能导出，逐值对比 XYZ 与 CSV；不能把 nm 坐标再除以1000，也不把数值截为两位小数。

Origin 用原有功能导入 CSV，X=RMSD(nm)、Y=Rg(nm)、Z=相对自由能(kJ/mol)。按用户选择画颜色映射曲面＋底部投影或其他已确认图型。PPT 的投影100改0是投影从 Z 轴顶部移到底部，不改能量。保留轴/色标和本次插值、模板选择。保存 gibbs.opju、gibbs.png，重开核对导入数值、方向、投影和原生绑定；不使用一维折线 worker 冒充 FEL。

用户选择二维参考图时，使用 Origin 原生 `impASC` 导入和 `plotxyz` 的 XYZ 等高线类型 243、TriContour 模板；226 是矩阵等高线，不能用于 XYZ 列。实际验证及接口要点见 [fel-origin-native.md](fel-origin-native.md)。此路径调用应用原有功能，不新增 FEL 替代脚本。

## 检查与排错入口

| 现象 | 先检查 | 处理原则 |
|---|---|---|
| out.xvg 列错位/时间不同 | 原 XVG 的变宽前导空格、重复时间列、窗口和帧数 | 用 Excel 原有固定宽度导入重新整理副本，核对全部帧；不筛行掩盖错误 |
| SHAM 把时间当第三坐标 | out.xvg 是否三列、-time 设置、实际输出维数 | 先纠正已确认格式，再在新目录执行，不从多个 pairwise 输出中随意挑图 |
| Bash 报 gibbs 空格.xpm 不存在 | 原脚本是否额外加了 -xyz、路径/环境 | 沿用原脚本默认 XYZ 用法；其他需修改原脚本的办法先让用户选 |
| XYZ 重复、Origin 网格点数翻倍 | 原脚本追加输出，是否重复运行 | 保留诊断，用新的空目录重做，不能删一半行伪装成功 |
| 图灰底/未采样区被当高能 | XPM 封顶值、bindex 占用与 Origin colorAbove | 按已确认样式仅改显示，不改原网格；封顶值不通用 |
| Origin 回读为空或首行错位 | 导入后的真实表名、COM 数组上下界 | 用数据树和 GetLowerBound/GetValue 核对；不把空值转0后比较 |
| 最低箱到构象时间不符 | 输入样本序号、GRO结构帧、所载轨迹起点/频率和计数基准 | 按选取能量最低点核对实际时间/坐标，不套固定偏移 |

方法结果与显示结果分别验收：原始数据完整，SHAM及原 Bash 成功，XYZ→CSV逐值一致，Origin重开后全表一致，图型/色标/方向/单位符合选择。失败时保留日志，不反复盲跑，不把旧输出当本次结果。

## 5. 选取能量最低点

完整方法、中文选帧、后台 VMD 原生命令及无溶剂 PDB 导出见 [选取能量最低点](energy-minimum.md)。从当前 gibbs.log 的最低箱到 bindex.ndx 组成员，再回查 out.xvg 的真实时间；多个候选由用户选择。核对匹配结构＋md_noPBC.xtc 的加载方式与帧时间，不套固定偏移，保留完整目标组分。具体候选与导出结果只保存在项目中。

PPT 的 FEL.py、min_protein.tcl 仍缺完整原件；只有用户指定调用这些历史脚本时才需要补齐，不阻断已授权的原生 VMD 路径。

## 输出与验证边界

沿用 PPT/实际文件名 rmsd-fel.xvg、rg-fel.xvg、out.xvg、gibbs.xpm（或相应 pairwise 输出）、gibbs.log、bindex.ndx、原脚本同主名 XYZ/PNG、导入 Origin 的 CSV/OPJU。体系、窗口、图型、重复运行由目录区分。

原件解读与哈希在技能资源中保留；每次计算、转换、二维/三维作图及构象导出分别记录真实核验结果。二维 Origin 操作见 [fel-origin-native.md](fel-origin-native.md)。不能将一个体系或一个分支的成功视为其他体系、原 Python PNG、三维曲面或历史脚本已经通过。

依据为用户 PPT/脚本与实际版本帮助；参数参考 [GROMACS sham](https://manual.gromacs.org/documentation/2020/onlinehelp/gmx-sham.html) 和 [XPM 格式](https://manual.gromacs.org/documentation/2020/reference-manual/file-formats.html#xpm)。
