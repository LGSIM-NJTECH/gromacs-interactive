# 单项：按残基 RMSF → CSV → Origin

用户预设命令为 `gmx rmsf -s md.tpr -f md_noPBC.xtc -res -o rmsf_<D>ns.xvg -b BEGIN_PS -e END_PS`，选择实际菜单中的 Protein。历史编号 1 不写死。此定义是蛋白组的逐残基原生汇总，不是 Cα RMSF。若改用其他组、质量定义或拟合方法，先让用户选择再记录。

1. 使用已核对原子顺序/数量和 PBC 的轨迹及匹配 TPR。先读取真实时间范围、帧间隔、链和残基编号。通过中文选项让用户选择分析区间；区间必须有真实帧支持，不能把 80–100 ns 套用到 2 ns 轨迹。
2. 按 `(END_PS-BEGIN_PS)/1000` 命名，例如 0–2000 ps 为 `rmsf_2ns.xvg`，50000–100000 ps 为 `rmsf_50ns.xvg`。小数不取整。同长度不同区间用不同目录区分，并在记录中保留两个端点。
3. 读取当前版本帮助，记录拟合开关。2020.6 原生默认 `-fit yes`，按所选 Protein 做最小二乘叠合，参考来自对应 TPR。沿用用户命令，不擅自换成骨架拟合、Cα 或 `-nofit`。
4. 用持久终端读取真实菜单，输入用户已明确的 Protein 组号。成功后核对输出有限、非负、行数与实际组的残基映射一致。遇多链编号重复/不连续，检查链及插入码，不能按行号伪造残基编号；需要更复杂映射时先单独适配。
5. 用 `scripts/observable_csv.py --metric rmsf --input XVG --output SAME_STEM.csv --begin-ps BEGIN_PS --end-ps END_PS` 导出。列为 `residue_number,rmsf_nm`，原生数值不变，残基编号不除以 1000。程序检查时长与文件名、单位、有限值、横轴唯一递增，保留源/输出哈希和区间。程序不从 RMSF XVG 单独证明源轨迹实际覆盖，仍需前置时间核验。
6. 进入 origin-csv.md，每次问图型、模板及平滑选择。单轨迹通常原始折线；横轴 Residue number，纵轴 RMSF (nm)。Origin JOB 设置 `x_axis_kind: residue`，轴刻度采用合适整数步长。没有独立平行不生成误差带。
7. 输出主名继承时长，如 `rmsf_2ns.csv/.opju/.png`。重开 OPJU 核对每个残基数值，查看 PNG 的单位、编号、峰位置、图例及裁切；记录检查结果后再进行下一项。

短时间窗口的 RMSF 仅描述该段采样，不据此声称柔性已收敛或催化性能提高。跨体系对比必须确认残基映射、计算组、拟合、窗口和采样条件一致，不能直接按两张表的行号相减。
