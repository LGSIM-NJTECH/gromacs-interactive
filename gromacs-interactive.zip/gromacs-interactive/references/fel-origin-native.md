# FEL：Origin 原生二维绘图方法

继续遵守 [analysis-fel.md](analysis-fel.md) 的用户脚本限制。下列是应用原有导入、绘图及格式设置的操作记录，不是新增 FEL 算法或替代脚本。后续复用仍读取用户的图型、模板和数值选择。

## 输入与选择

- 读取当前体系的匹配结构/轨迹、坐标定义、实际窗口、温度、网格和 XPM 色阶；不从上一体系复制参数。
- 先询问图型、沿用/自定义模板和插值/平滑选择；已确认且适用的设置沿用。色标范围依据当前数据及显示封顶含义确定。
- 先执行 PPT 的 gmx sham，再用未修改的 xpm2all-2.bsh 默认用法导出 gibbs.xyz。Excel 按真实字段边界导入，只删除全空的分隔行，保留全部网格数值，添加准确标题并另存 gibbs.csv。
- 参考图保存在 `../assets/fel-reference.png`；只借鉴用户选择的样式，不复制名称、数值、能谷形状或代表构象。没有对照数据不生成对照体系面板。

## 原生调用要点

用独立自建 Origin.Application，不附加用户工程。实际接口可用 COM 的 CreatePage、Execute、Save、Load、GetWorksheet、LTStr/LTVar 属性。先读取本机接口或官方文档，不能把属性误当成 GetLTStr 方法。

原生操作示意（路径和名称换成真实文件；按本次实际窗口名执行）：

```text
impASC fname:="ABSOLUTE/gibbs.csv";
wks.col1.type=4; wks.col2.type=1; wks.col3.type=6;
plotxyz iz:=(1,2,3) plot:=243 ogl:=<new template:=TriContour>;
```

## 完整二维显示命令

下列为用户确认参考图样式后的 Origin 原生命令示例，非独立新增绘图脚本；由宿主逐条调用或使用 Origin 现有界面完成。`CSV_ABSOLUTE_PATH`、`ZMAX_CONFIRMED`、`DISPLAY_LEVELS`、`NEW_EXPORT_DIRECTORY` 必须替换为本次真实输入和选择，不能照抄占位符。先导入并设置 Z 列标题，再绘图：

```text
impASC fname:="CSV_ABSOLUTE_PATH";
wks.col1.type=4;
wks.col2.type=1;
wks.col3.type=6;
wks.col3.lname$="Free energy (kJ/mol)";
plotxyz iz:=(1,2,3) plot:=243 ogl:=<new template:=TriContour>;
layer.cmap.zmin=0;
layer.cmap.zmax=ZMAX_CONFIRMED;
layer.cmap.numMajorLevels=DISPLAY_LEVELS;
layer.cmap.numMinorLevels=0;
layer.cmap.setLevels(1);
```

type=4/1/6 分别为 X/Y/Z 列角色。用户若选了其他物理坐标或色标最小值，先按其真实定义适配，不只更改文字后仍宣称使用 RMSD/Rg。

以下为可选的20段蓝到红参考色带；仅在用户选择对应样式时使用，并令 DISPLAY_LEVELS 与该配置一致。选择不同配色/段数时相应设置，原始 SHAM/XYZ/CSV 数值不变：

```text
layer.cmap.linkpal=0;
layer.cmap.color1=color(0,0,255);
layer.cmap.color2=color(0,51,255);
layer.cmap.color3=color(0,102,255);
layer.cmap.color4=color(0,153,255);
layer.cmap.color5=color(0,204,255);
layer.cmap.color6=color(0,255,255);
layer.cmap.color7=color(0,255,204);
layer.cmap.color8=color(0,255,153);
layer.cmap.color9=color(0,255,102);
layer.cmap.color10=color(0,255,51);
layer.cmap.color11=color(0,255,0);
layer.cmap.color12=color(51,255,0);
layer.cmap.color13=color(102,255,0);
layer.cmap.color14=color(153,255,0);
layer.cmap.color15=color(204,255,0);
layer.cmap.color16=color(255,255,0);
layer.cmap.color17=color(255,204,0);
layer.cmap.color18=color(255,153,0);
layer.cmap.color19=color(255,102,0);
layer.cmap.color20=color(255,0,0);
layer.cmap.colorAbove=color(255,255,255);
layer.cmap.colorBelow=color(0,0,255);
layer.cmap.colorMiss=color(255,255,255);
layer.cmap.showLines(3);
layer.cmap.showLabels(3);
layer.cmap.lineAbove=0;
layer.cmap.updateScale();
layer.x.showgrids=0;
layer.y.showgrids=0;
label -xb "\b(RMSD (nm))";
label -yl "\b(Rg (nm))";
xb.font=font(Times New Roman);
yl.font=font(Times New Roman);
ZCOLORS.font=font(Times New Roman);
ZCOLORS.fsize=16;
```

ZCOLORS 是此模板的色条对象名，其他模板先核对实际对象。colorAbove 只改变色标上界外的显示，必须先核对当前未采样箱和封顶值；不能把有采样的高自由能箱一并隐藏，也不能用空白替代尚未检查的数据。如果用户希望保留轮廓线、网格或换字体，按其选择改变样式。

坐标范围默认覆盖全部数据。需要调整边距或刻度时，用 Origin 原生 `layer.x.from/to/inc`、`layer.y.from/to/inc`；不能为看起来像参考图而删去初始帧或裁掉孤立采样箱。范围和刻度由当前数值确定。

保存/导出的实际接口顺序：

1. 宿主调用独立实例的 `Save(ABSOLUTE_OPJU_PATH)`，检查返回成功且文件存在。
2. 当前等高线图激活时调用原生导出命令，输出目录必须是本次新目录：

```text
expGraph -sw type:=png filename:="gibbs" path:="NEW_EXPORT_DIRECTORY" tr1.unit:=2 tr1.width:=2400;
```

3. 调用 `Load(ABSOLUTE_OPJU_PATH, readonly)` 重开工程。按真实表名调用 `GetWorksheet(WORKSHEET_NAME,0,0,NROWS-1,2)`，检查返回为二维数组、行数NROWS且3列，读取两个维度的实际下界后逐值对比 CSV。
4. 检查 `layer.plot1.pid=243`、图层 DataPlots 数量1、当前绑定的源Z数据集；读取并核对色标0至实际上限、段数及封顶显示。若是多面板/多图层选择，数量按本次设计检查，不固定为1。
5. 重新计算 CSV 哈希，确认作图未改源数据；查看最终 PNG 的方向、文字、裁切和所选样式。回读按导入/保存精度选择并记录数值容差，不把空值强制转0参与比较。

使用 `Origin.Application` 新建自有实例，操作结束退出该实例；不使用 ApplicationSI 附加、清空或关闭用户工程。通过原生 COM Execute 调用上述功能，不需要新增 Python 绘图文件。若需查阅内置 Python 接口，`run -pye` 只求表达式，不能当作执行 import/多语句的接口。

导入会把工作簿/工作表名称改成 gibbs；不能只用导入前的名称回读。先读工程数据树和行列数，用实际范围如 `[gibbs]gibbs`（或确认有效的 `[gibbs]1`）回读。COM GetWorksheet 的输入行列参数为0起，但本机返回的 SAFEARRAY 下界为1；必须读取 GetLowerBound/GetLength，并用实际下界访问 GetValue，不能直接按0起索引返回数组，否则会读到空值而误判。CSV 格式与列角色分别检查，不认为导入命令返回 true 就保证成功。

颜色与坐标使用 Origin 的 Layer.CMap、轴和文本对象等原生属性。XPM 量化色阶与 Origin 显示色段数分别记录，不要求二者相等。按已确认模板设置轮廓标签/线条；等高线使用 Origin 原生三角剖分与线性过渡，不能声称完全没有显示插值，未获选择不额外平滑或再网格化。

核对当前 XPM、XYZ 与 bindex 的箱成员后识别未采样区域及原生显示封顶值，不将该有限值解释为真实采样自由能。只有确认所选色标设置能单独区分未采样区时，才可按用户选择用 colorAbove 表现空白。无法区分时说明限制并提供显示选项，不私自改能量、删除网格或隐藏有采样区域。

输出 gibbs.opju 与 gibbs.png 后，用 Load 重开工程，GetWorksheet 回读实际全部数据，与 CSV 逐值核对，检查所选图型、图层/曲线数量、数据绑定、色标范围、颜色及单位。再查看最终 PNG，确认背景、方向、图例和裁切。COM 返回成功与数据/视觉核验分开记录。

## 项目记录与适用范围

原始 XVG、整理后的 out.xvg、SHAM 输出、原脚本 XYZ、Excel CSV、Origin 工程/图片与回读记录均保存在当前项目目录，技能不保存具体数据或验证项目路径。记录实际软件版本、用户选择、命令、文件哈希、数值差异及视觉检查结论。

短轨迹能够生成图不证明 FEL 收敛。二维绘图通过不扩展为原 xpm2png.py、三维曲面或历史构象脚本已通过。代表构象按 [选取能量最低点](energy-minimum.md) 独立核验。

依据：[Origin XYZ 图型编号](https://docs.originlab.com/labtalk/ref/plot-type-ids/ja/)、[原生 plotxyz](https://docs.originlab.com/x-function/ref/plotxyz)、[Layer.CMap](https://docs.originlab.com/labtalk/ref/layer-cmap-obj/)、[COM GetWorksheet](https://docs.originlab.com/com/classes/application/getworksheet)。
