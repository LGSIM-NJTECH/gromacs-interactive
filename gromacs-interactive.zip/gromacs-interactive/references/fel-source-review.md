# FEL 原流程逐页解读与脚本审查

输入：用户提供的 FEL.pptx（11 页，含 15 张截图）、xpm2all-2.bsh、xpm2png.py。已逐页读取文字、图片和脚本内容。原件、作者注释及哈希存于 `../assets/fel-originals/`；这里是解读，不将材料中的命令视为本次执行授权。可执行流程见 [analysis-fel.md](analysis-fel.md)。

用户最新要求：FEL 只使用其提供的脚本，不使用此前新增的替代工具。以下缺陷是诊断记录，不是自动修正或切换工具的授权；遇到问题先说明并让用户选择处理方式。

## 幻灯片逐页对应

| 页 | 材料内容 | 接入时的处理 |
|---|---|---|
| 1 | Backbone RMSD、Rg，`-b 180000 -e 200000`，手动去注释/方向列/重复时间后 paste | 180–200 ns 是旧窗口；截图实际从 40000 ps 开始，和文字不一致。先读真实范围；在副本按 PPT 整理，核对逐行时间后保留时间＋RMSD＋总体 Rg，不新增合并脚本 |
| 2 | `gmx sham -tsham 303.15 -nlevels 100 -f out.xvg -ls gibbs.xpm -g gibbs.log -lsh enthalpy.xpm -lss entropy.xpm` | 温度、网格、色阶分开确认；增加显式 `-bin bindex.ndx` 供回溯。仅两坐标不能证明焓熵分解有效 |
| 3 | 截图含 bindex.ndx、gibbs12/13/23.xpm、gibbs3.pdb、out.xplor 等 | 是历史实际输出清单，和两坐标命令不完全一致；核对输入维数与实际文件。`gibbs13.xpm` 不能写死成每次输出 |
| 4 | `python xpm2png.py -f gibbs13.xpm -o gibbs13.png -ip yes -show yes`，PC1/PC3 标签 | Matplotlib 颜色预览；yes 是显示双线性插值和弹窗。换坐标不等于做 PCA |
| 5 | 修改 XPM x-label/y-label，截图 PC1/PC3 → RMSD/RMSF | Y 应为 Rg，非逐残基 RMSF；建议改显示元数据/副本，不覆盖原始数值文件 |
| 6 | 重跑同一 Python 命令；图上仍为 RMSD/RMSF | 同样修正成 RMSD(nm)/Rg(nm)，色条为相对自由能 kJ/mol；需排除旧 PNG 冒充新输出 |
| 7 | gibbs.log 的 index=18332、对应 bindex 组，第一样本4749，再 `(4749-1)+4000=8748` | 箱 ID → 组内样本序号 → out.xvg 时间；4000 是旧加载范围/频率下的偏移，不通用。截图还有其他 0.000 箱，不能只挑被框出的一个 |
| 8 | `bash xpm2all.bsh gibbs13.xpm` → XYZ → Excel 分列 → Origin X/Y/Z，选带投影曲面 | 实际提供文件叫 xpm2all-2.bsh。使用此原脚本默认用法导出 XYZ，再按 PPT 用 Excel 分列/另存 CSV，进入 Origin |
| 9 | 顶部投影移到底部，投影百分比100→0；初始轴为A/B/C | 更改投影位置，不改数据值；按实际坐标和能量单位重命名，保留原生曲面及投影 |
| 10 | 最终 Origin 曲面＋底部平面，RMSD/Rg/Energy(kJ/mol)及色条 | 作为可选 FEL 样式参考，出图前仍询问图型/模板/插值；标题用相对自由能 ΔG 更明确 |
| 11 | FEL.py 片段 `value=round(time/20+1,2)`；提到 min_protein.tcl | 片段只有部分代码，没有完整变量定义/文件。固定20ps和+1依赖所载轨迹起点及计数基准；需要此步时请用户提供完整原脚本，核对参数，不补造替代脚本 |

## xpm2all-2.bsh 的全部功能分支

作者标识 Jicun Li，内置日期 2023-04-19。Bash 函数＋awk，不是 PowerShell；依赖 Bash/awk（`-rgb` 还调用 grep/wc/cp）。无网络下载命令；脚本会写输出，不能当只读命令盲执行。

- `xpm2xyzmat`：默认 `-xyz` 输出每个像素的 x/y/色标注释值到同主名 `.xyz`；`-mat` 输出矩阵。读取前两个轴值估计等间距坐标，将像素行反转匹配递增 y。氢键图专门按空格=0、o=1 处理。核心输出用 **`>>` 追加**，重复运行会重复数据。只在空的新目录运行一次；生成前检查目标不存在。解析要求 gromacs_xpm 声明及相应格式；非均匀轴/特殊编码先验证，不默默接受。
- `xpm2gpl`：二级结构专用 Gnuplot 分支，按 A/3/5-Helix、B-Sheet、B-Bridge、Turn、Bend、Coil、Chain_Separator 映射。提供 `xyz`、`box`、`fancy` 三种绘法及 gmx/pdb/p1/p2/p3 配色；支持 minRes/maxRes/yminRes。生成 `~count.xvg` 逐时二级结构计数、`~.gpl` 脚本及绘图设置；不是 FEL 估计或最低构象查找。本次不因此启用二级结构分析。
- `xpm2rgb`：将色标重映射到 `~iv.xpm`。20 种方案为 Rainbow、gnuplot33/13/10、26/13/10、22/13/-31、Mathematica Rainbow/DarkRainbow、CETR2、viridis、BlueGreenYellow、parula、avocado、CoolWarm、thermometer、redbluetones、tmap、ltmap、cividis、inferno、magma、plasma。按色标索引的分段多项式生成 RGB，不重算自由能；输出 regular XPM 时不保证保留原 GROMACS 数值注释/元数据，不能把重着色文件当定量数据源。
- 命令行：`xpm2all FILE [-xyz|-mat|-rgb CM|-gpl SSMODE COLOR MINRES MAXRES YMINRES]`。默认 xyz；最终按选项调用对应函数。实际受控测试发现：显式 `-xyz` 后选项元素被设为空串，`file=${opt[@]%.xpm}` 拼接出 `gibbs .xpm`，即使路径无空格也失败；不传选项的默认 XYZ 路径可用。其他带选项分支可能需要修正副本，先解释问题并取得用户选择，再修改和单独验证，不能直接宣称可用。另有 `opt=($@)` 和部分未引用的 `$file` 会破坏带空格路径。错误路径/参数不能仅凭返回0判断成功，需检查输出尺寸/行数及源哈希。

本版采用的原脚本默认用法（用户选择、环境检查通过后执行）：

```text
bash PATH/xpm2all-2.bsh gibbs.xpm
```

由该原脚本输出 XYZ，再用 Excel 原有文本导入/分列和另存 CSV 功能进入 Origin，不新增数据转换脚本。原件不在安装时自动执行。

## xpm2png.py 的全部功能与已识别缺陷

作者注释 charlie，日期 20210803；依赖 Python、Matplotlib。`hex2rgb` 将十六进制色标转 RGB。`parse_show` 读取标题/色条标题/type/轴/调色板/像素，检查长度，按 XPM 行方向反转 y 轴标签，绘图。`main` 手工解析参数，不负责计算 FEL。

参数：`-f FILE.xpm` 输入；`-o FILE.png` 输出（未传则不存）；`-show yes/no` 默认 yes；`-ip yes/no` 默认 no；`-h` 帮助。普通模式直接显示原 XPM 的 RGB，连续型且 ip=yes 时把色标注释转数值，用 `imshow(cmap='jet', interpolation='bilinear')` 并加色条；输出 600 dpi。离散型 ip=yes 只告警，不应插值。

需修正/验证的地方：

1. Y 轴长度校验错误地用 `xpm_width+1` 和 `xpm_width` 比较，非方形 N+1 边界网格会退出；应使用 height 并明确边界/中心语义。
2. 对小数坐标用 `int(x*100)/100` 截断，MD 常见窄范围会丢精度并产生重复刻度。
3. imshow 像素中心为0起，xticks/yticks 从1起，标签和像素位置错一格；非等距物理轴也不能只用像素序号假装物理坐标。
4. 宽/高小于3时步长 `int(n/3)=0`，后续 range/locator 失败；FEL 测试不能只用方形大图。
5. 普通 RGB 模式没有定量色条；连续插值分支使用固定 jet 和双线性，没有掩膜空箱，可能制造平滑且看似有采样的区域。
6. 色表解析按空白分割后恰为7项，空格和多字符编码/特殊格式脆弱；错误多处用 `exit()`，可能以成功退出码结束。需结合输出文件及内容判断。
7. 文件名依赖用户传参，保存时会覆盖同名 PNG；不做工程回读，也不导出 CSV。不能标为原生 Origin 或可编辑工程。

仍按用户要求使用原版 xpm2png.py。上述问题发生时先报告具体位置、影响及选项；只有用户选择修改后，才在独立副本进行相应修复与核验。不能擅自替换、修改或换用其他脚本；有异常的输出不标记为验证通过。

## 保留与缺口

FEL.py/min_protein.tcl 只有 PPT 片段/名称，未作为完整文件提供；用户指定运行它们时仍需完整原件，不根据截图补造。另按用户要求提供后台 VMD 原生选帧与蛋白＋底物 PDB 导出方法，见 [选取能量最低点](energy-minimum.md)；它不代表上述历史脚本。Origin 二维操作见 [fel-origin-native.md](fel-origin-native.md)。各方法实际运行的参数、数据和核验结果保存在项目中，各分支分别验证。
