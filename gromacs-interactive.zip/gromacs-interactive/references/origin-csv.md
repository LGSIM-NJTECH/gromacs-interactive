# CSV → Origin 自动绘图（同一 Skill 内的单步模块）

## 每次出图都询问

1. 先检查 CSV 的横轴、单位、各列含义及独立重复来源，再用中文选项框询问图型。单轨迹提供折线/散点连线；多平行可选择各平行折线、均值折线、均值＋平行间样本 SD。无平行不能捏造误差带，相关帧不能冒充独立重复。SEM、CI、上下限带须明确其定义，不混称 SD。
2. 另行询问“沿用当前模板”或“提供自定义模板图片”。选自定义时在普通聊天中请用户附图，不通过只能收文字的异步工具索图。参考图片仅用于样式，不复制其数值、刻度、标签或科学标记。新的模板保留为新版本并记录来源。
3. 询问是否平滑及方法、窗口。若已确认复现历史 WT/MUT 图，RMSD 使用 0.6 ns、Rg 使用 0.2 ns 的居中滑动平均，RMSF 按残基直接绘制。滑动平均仅用于显示时间图的均值线。CSV、工作表中的原始均值及标准差、误差带上下界均按原始点保留。

RMSD、Rg、RMSF 各有独立的 Origin 图样。均使用浅灰主网格、左上图例、深蓝和砖红实线。普通单轨迹分析沿用该指标的版式和白底原始折线。WT/MUT 对照输出原生透明 PNG，并保留可编辑的 OPJU；适合放在浅色幻灯片上。时间、单位和轴范围从实际数据确定。

| 指标 | 参考图 | 图样和历史平滑设置 |
| --- | --- | --- |
| RMSD | [RMSD](../assets/origin-reference.png) | 宽幅时间轴、淡色带、纵轴上方留白。历史对照均值线 0.6 ns。 |
| Rg | [Rg](../assets/origin-reference-rg.png) | 按实际半径收紧纵轴，保留小数刻度和淡色带。历史对照均值线 0.2 ns。 |
| RMSF | [RMSF](../assets/origin-reference-rmsf.png) | 按整数残基编号绘制，色带更实，保留逐残基峰值。均值线不平滑。 |

## 文件与执行

CSV 从对应指标结果导出，保留物理量和单位，例如 `rmsd.csv`、`rg.csv`、`rmsf_50ns.csv`；作图不自动运行其他分析指标。输出继承主名，如 `rmsd.opju`、`rmsd.png`，与 CSV 一同放入 MD_ROOT 的对应模块目录，见 [目录规则](project-layout.md)。不再额外层叠 Origin/验证目录，旧输出按规则复用或备份。

FEL 的 `gibbs.csv` 为二维网格/XYZ 数据，转入 [analysis-fel.md](analysis-fel.md) 的 Origin 分支；本页一维 worker 不支持 FEL 曲面，不以折线图测试代替曲面验证。

## WT/MUT 对照绘图

每个指标用一张已对齐的 CSV。RMSD 和 Rg 的横轴为 `time_ns`，RMSF 的横轴为 `residue`。每组保留至少两条独立轨迹的值，例如 `WT_rep1_nm`、`WT_rep2_nm` 以及对应的 `WT_mean_nm`、`WT_SD_nm`，MUT 同理。统计列保留足够有效位，准备工具会从平行列逐行核对平均值及样本 SD。先确认 RMSF 的链和残基映射、两组的分析区间及选组定义，不能仅凭 CSV 数值相同来判断体系可比。

MolPilot 从「RMSD / RMSF / Rg → WT/MUT 误差带绘图」进入。选择指标，填写当前项目内 CSV 的相对路径，确认显示平滑窗口，再运行。Skill 可用同一 worker 生成 JOB 并执行原生 Origin。

```powershell
python scripts/origin_csv_plot.py --prepare-comparison rmsd INPUT.csv OUTPUT_DIR JOB.json --smoothing-ns 0.6
python scripts/origin_csv_plot.py JOB.json --check-only
powershell -File scripts/run_origin_csv.ps1 -Job JOB.json
```

按所选指标换成 `rg` 或 `rmsf`。省略 `--smoothing-ns` 即保留原始均值线。每次出图使用新结果目录。

先使用普通 Python 3 执行 `scripts/origin_csv_plot.py JOB.json --check-only` 验证 CSV/映射，不启动 Origin。确认选项后，用 PowerShell 执行 `scripts/run_origin_csv.ps1 -Job ABSOLUTE_JOB_JSON`。它新建独立 `Origin.Application`，用 Origin 内置 Python/originpro 导入 CSV 的横轴和所选作图列、创建原生工作表和图形、保存工程与 PNG，再重开工程逐列核对这些数据。其余列保留于 CSV，不自动导入或绘制。

不附加、清空或关闭用户已有工程，不用 ApplicationSI 兜底，不改 Origin 安装、注册表或 DCOM。沙箱无法访问当前用户 COM 时，只为确切绘图命令申请必要的本机执行权限。启动失败保存诊断后停止，先定位原因再进行有依据的修复，不能连续盲重试。

## 任务配置

JOB.json 是用户实际选择的记录，不是执行授权的替代。字段：

- `csv`、`csv_sha256`：实际 CSV 绝对路径和哈希，变化后停止重新核对。
- `output_dir`、`stem`：新输出目录及指标主名。
- `chart`：`line`、`scatter-line` 或 `mean-sd`；`chart_confirmed`、`template_confirmed` 必须基于真实回复。
- `x_column`、`xlabel`、`ylabel`：明确横轴列及带单位轴标题。
- `x_axis_kind: residue`：RMSF 使用整数残基刻度；时间曲线省略此项。残基编号不转换为 ns。
- `y_axis_kind: count`：原始非负整数计数的纵轴，采用整数主刻度；不用于均值误差带。
- 可选 `column_metadata`：按 CSV 列名指定 `long_name`、`units`，写入 Origin 列标签行并在工程重开后核对。
- 可选 `page_size`：`width`、`height` 为 Origin 页面尺寸，范围各为 1000–30000；省略沿用宽幅，画幅由用户确认模板决定。
- `series`：每条曲线的 `label`、`y_column` 和 HEX `color`。前两条可省略颜色以使用默认蓝红。
- `metric` 可显式填写 `rmsd`、`rg` 或 `rmsf`，通常从输出主名识别。手工配置的普通图用 `background: white`，透明导出用 `background: transparent`。比较准备命令自动使用透明底。默认不添加额外参考线。
- 可选 `display_smoothing_ns` 只用于用户已确认的、等间隔采样的时间均值误差带图。填写 `x_unit: ns` 或横轴列的 `units: ns`。居中窗口在两端使用实际可用的数据点；Origin 另存显示列，原始统计列继续用于误差带。

mean-sd 还需要各序列的 `sd_column`、`independent_replicates`（至少 2）与 `error_semantics: sample_sd_between_replicates`。上游正确计算均值/样本 SD 后才渲染。误差带使用原生均值 ± SD 上下界列及曲线填充，重新打开工程后逐点核对上下界。MolPilot 的单轨迹分析入口沿用同一模板，Skill 可以对具备真实均值和 SD 列的 CSV 绘制误差带。

## 验证与交付

必须同时检查：CSV 所选列与工作表逐行一致、工程重开成功、图形绑定和曲线数量正确、PNG/OPJU 确实存在。保存 JOB、CSV 哈希、origin-readback.json、错误日志（若有）。再查看导出图，核对单位、图例、颜色、轴范围、裁切和平滑/误差含义。数据回读与视觉检查分别记录。

不能将 Python 预览图或旧 PNG 冒充 Origin 新出图。新模板/图型在真实数据验证前标明待验证。当前 worker 不自动添加尚未实现的模板属性；用户选了新格式后先适配，而不是声称已经应用。

数据点数、具体模板选择和核验结果写入当前项目记录，不写入技能。折线、误差带、散点连线与自定义模板分别验收，不能用一个分支的成功代替其他分支验证。
