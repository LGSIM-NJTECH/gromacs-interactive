# 通道：PyMOL 三维制图

这是 [通道](channel.md) 的制图子步骤，沿用当前项目已确认的结构和通道选择。使用实际安装的 PyMOL 原生功能制作图片和可编辑 `.pse` 会话；不重新计算 FEL 或通道，不将本次制图数据打包进技能。

## 通道模块内部的自动衔接与模板

这是同一个 skill 的“通道”模块内部步骤；用户已明确要求通道分析完成后自动用 PyMOL 作图。完成当前通道选择和原生数据核验后，直接执行本节，不再等待额外的制图指令，也不重复询问是否沿用已确认模板。没有可用通道、用户尚未选择通道或结构/半径映射未通过时，先解决对应前置条件，不制造占位图。

默认沿用用户已确认的 [蓝色蛋白／黄色通道参考模板](../assets/channel-reference.png)：白底、蓝色全酶 cartoon、浅灰透明表面、黄色不透明通道球、橙色底物 sticks、细轮廓、不加标签。可复用参数为：蛋白 RGB `[0.25,0.43,0.56]`，表面 `[0.76,0.80,0.82]`、透明度 `0.78`，通道 `[1,0.77,0]`，底物 `[0.93,0.39,0.05]`；默认 1800×1600 px、300 dpi。模板只确定显示风格，不决定新体系的构象、链、原子数、通道编号、球数、半径和相机矩阵。技能保存该模板和通用绘图程序，不保存已验证体系的图片/PSE/数据作为模板输入。

用户明确希望更换样式时再显示中文选项，包括“提供一张参考图，按图中样式制作”和“继续使用已有模板，查看初稿后调整”。选择新参考图后，在聊天中接收图片；已经收到时不重复索取。不自动添加参考图中不存在的残基、距离或氢键标签。用户明确只要通道数据时尊重其范围。

## 随包程序与配置

使用 `scripts/render_channel.py`，它只执行 PyMOL 原生渲染及会话回读，不重算通道。由代理从当前项目的选帧、通道选择及原生核验记录生成 `tunnel/pymol-input.json`。所有相对路径均以该 JSON 所在目录为基准，不依赖脚本安装位置或工作目录。

| 配置字段 | 含义 |
|---|---|
| `structure` | 当前已核验的蛋白＋底物 PDB 路径；单个 state，无需底物时使用纯蛋白 PDB |
| `protein_atom_ids` | 当前 PDB 内实际蛋白原子的 serial 列表，来自真实索引/导出映射，不是通用组号或 VMD index |
| `ligand_atom_ids` | 需显示的实际底物原子 serial 列表；没有底物时为 `[]`，不假造底物 |
| `channels` | 已由用户选择的通道数组；每项 `id` 为当前真实显示编号，`pdb` 为经原生映射定位的实际 PDB 路径，不拼接未经核对的文件名 |
| `radius_field`、`radius_unit`、`radius_semantics_verified` | 经原生查看器/输出约定核实后填 `"b"`、`"angstrom"`、`true`；不能仅为让程序通过而填写 |
| `output_dir` | 通道模块目录，通常 `"."` |
| `source_sha256` | 建议填入已确认的输入相对路径→SHA256，用于防止验证后文件变化 |
| `style` | 可选，按用户明确变更覆盖程序中的模板参数；不影响通道坐标或半径 |

蛋白与底物 serial 必须唯一、互不重叠并覆盖输入结构。多链按真实编号映射；重复 serial、混合模型或未知组分不能通过删原子来绕过检查。需要显示的辅因子应先确认其角色与映射；不适合当前蛋白/底物表示法时由代理调整原生场景并按本节同等核验，不承诺任意体系直接套用。

检测当前已安装 PyMOL 的 Python（可导入 `pymol2`、NumPy），再调用：

```text
PYMOL_PYTHON SKILL_DIR/scripts/render_channel.py --config MD_ROOT/tunnel/pymol-input.json
```

`--check-only` 只检查输入配置和 PDB，不导入 PyMOL、不写出图；不能把它当成完整渲染验证。正式运行默认输出 `channel.png`、`channel.pse`、`channel-render.json`。需要保留既有已确认图片时，在同一个 `tunnel` 目录用 `--prefix channel-check` 验证更新后的程序，不覆盖原件。已有同名输出时程序拒绝覆盖，由代理按项目目录约定复用或备份。Windows 使用实际 PyMOL Python 启动独立隐藏进程，保存日志，不关闭或接管用户会话。

程序根据当前结构和所选通道确定初始相机，仅调整相机，不移动单个对象；无底物及多条已选通道均有独立分支。通道伪原子即使名为 H 也不删除；所有采样球按原生 beta→vdw、`sphere_scale=1` 显示。颜色通过原生 `cmd.iterate(... color ...)` 检查，不假定 `get_model()` 的 Atom 存在 `color` 属性。

运行成功会报告 `passed_native_readback`，图片检查初始为 `pending_agent_image_inspection`。代理必须查看真实 PNG，必要时在当前场景调整相机或显示设置并重新保存/回读，不能把程序返回成功当作图像已审查。

## 输入与几何不变量

- 从项目选择记录定位通过核验的代表构象、通道原生 PDB、半径约定和 ID 映射；不硬编码路径、残基名、原子数或通道编号。多模型/多快照明确所选 state，不能将多个构象叠成一个静态通道。
- 根据拓扑/导出索引及真实结构标识建立蛋白、底物、指定辅因子选区，检查端基和修饰残基。不能仅靠 `polymer.protein`、`organic` 或 `resn MOL` 假定所有体系都正确。选区不全先修复选区，不删掉未识别原子来通过计数。
- 通道伪原子不是化学氢，不对它运行去氢、加氢、成键优化或力场计算。仅当原生格式确认 beta/B-factor 存储半径时将其赋给 `vdw`，用 `sphere_scale=1` 保留实际 Å 半径。不同导出格式按其真实半径字段处理。
- 结构和通道使用同一坐标系。调整视角使用相机，不分别旋转/平移某个分子对象。需要 WT/MUT 叠合时，对整个对应场景共同应用同一变换，保留原坐标和变换记录。
- cartoon、透明表面及球体只改变表示方式；不能重塑折叠、删除通道采样球、缩放半径或移动底物来模仿参考图。隐藏真实氢仅是显示选择，保留原始对象和源文件。PDB 缺乏键级信息时，底物 sticks 不可被解释为已经验证其化学键级；需要准确键级时使用匹配的可信结构/拓扑，并确认原子与坐标映射。

## 后台 PyMOL 操作

检测实际 PyMOL 版本与可用原生启动方式。可用 `pymol2.PyMOL` 时使用独立无界面实例；或按该安装版本的命令行帮助使用后台模式。不附加、清空或关闭用户现有会话，不修改全局安装和启动配置。Windows 启动后台进程时使用隐藏窗口并保存日志。

在项目内保存实际执行的 PML/原生 API 命令和参数。下列是命令结构示例，路径、选区、state、颜色、透明度和输出文件须替换为当前输入及选择；先核对对象名称与命令成功状态，不能直接运行占位符：

```text
load STRUCTURE_PDB, source_structure
create protein_object, VERIFIED_PROTEIN_SELECTION
create ligand_object, VERIFIED_LIGAND_SELECTION
load SELECTED_TUNNEL_PDB, channel_object
hide everything, all
alter channel_object, vdw=b
rebuild channel_object
set sphere_scale, 1.0, channel_object
show spheres, channel_object
show cartoon, protein_object
show surface, protein_object
show sticks, ligand_object and not hydro
color PROTEIN_COLOR, protein_object
set surface_color, SURFACE_COLOR, protein_object
set transparency, CONFIRMED_SURFACE_TRANSPARENCY, protein_object
color TUNNEL_COLOR, channel_object
color LIGAND_COLOR, ligand_object
bg_color BACKGROUND_COLOR
orient protein_object
zoom protein_object or ligand_object or channel_object
save OUTPUT_SESSION.pse
png OUTPUT_IMAGE.png, width=WIDTH_PX, height=HEIGHT_PX, dpi=DPI, ray=1
```

创建目标对象后隐藏/禁用原始完整结构对象，避免与蛋白、底物重复显示；源文件不删除。不存在底物时省去对应对象和命令，不能制造底物。多通道分别命名和着色，便于用户在 PSE 中单独开关。

PyMOL `transparency` 越大越透明，不能将模板“透明度”当作不透明度直接填写。通过当前版本 `help_setting` 核对细轮廓、正交投影、表面与 sphere 设置。需要细轮廓时可选择原生 ray tracing 的轮廓模式；设置只作用于显示，并记录是否适用于透明表面。不要用颜色表达未计算的势能或通道动力学。

初始相机可基于整体结构定向，再调整使所选通道和底物可见；不能保证不同构象有与参考图相同的朝向。保存实际 `get_view`/`set_view` 参数与选区。提供整体图时完整包含蛋白和通道，局部裁切、剖切/裁剪及透明背景需按用户选择处理，并在图注说明；不能隐藏被裁掉的通道范围而仍称其为完整通道。

## 验证与交付

先检查加载后真实对象数、state、原子/通道点数及元素/选区。逐点核对通道坐标和半径与原生数据一致，容差依据导出精度，不用调整半径掩盖误差。确认蛋白完整、指定底物均存在，未加入不需要的溶剂；记录源文件哈希，作图后复核不变。

保存 PSE 和图片到 MD_ROOT 的 `tunnel` 模块目录，通常使用 `channel.pse`、`channel.png`；多对象按实际选择使用简短编号，旧图按 [目录规则](project-layout.md) 复用或备份，不再层叠长验证目录。不仅检查文件存在：在另一个自有实例或清空本次自有实例后重新打开 PSE，核对对象、计数、state、坐标、半径映射、sphere scale、相机与关键显示设置。会话可编辑与图片渲染分别验收，不能用截图冒充原生会话。

查看最终图片，检查颜色、透明表面、通道可见性、底物、背景、边缘裁切及标签。将初稿交给用户，后续修改在已有场景上进行，不擅自更换构象或通道。项目保存命令、版本、选择、参数/视角、回读结果、图片和 `.pse`；技能只保存方法和参考模板。单体系制图通过不等于 WT/MUT 配对、所有新模板或所有导出格式已验证。

原生命令依据：[PyMOL 官方命令参考](https://pymol.org/pymol-command-ref.html)；具体行为以实际安装版本帮助和真实输出核验为准。
