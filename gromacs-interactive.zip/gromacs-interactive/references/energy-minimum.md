# 选取能量最低点

这是同一个 gromacs-interactive skill 的 FEL 后处理步骤。目标是找到最低相对自由能网格内的真实轨迹帧，按用户选择导出三维结构，供后续作图、通道及口袋分析。这里的“能量最低点”指所选反应坐标上的 FEL 最低自由能箱，不是逐帧势能最低，也不证明唯一最稳定构象或采样收敛。

## 1. 确认本次文件，再定位最低网格

- 读取本轮 FEL 输出目录中的 `gibbs.log`、`bindex.ndx`、`out.xvg`；记录绝对路径、运行来源及文件哈希。用户说“刚才生成的”时，从本次执行记录定位，不能替换为曾经附带的网络目录或其他历史体系。
- 主要结构输入是相匹配的 `md.gro` 与处理后的 `md_noPBC.xtc`；`md.tpr` 可用于 GROMACS 时间/坐标独立核验。确认 GRO 和 XTC 原子数、顺序及轨迹与 FEL 输入一致。
- 在日志的 `Minima sorted after energy` 部分查找最小 energy，保留所有并列最低的 index。日志前后可能重复列出同一箱，去重后报告；不把显示为 0.000 的精度误称为无限精度相等，必要时回查原始 SHAM 数据。
- 对每个最低 index，找到 `bindex.ndx` 中同名 `[ index ]` 组，读取完整成员直到下一个组头。index 是网格 ID；组内整数是从 1 开始的 SHAM 输入样本号，不是原子索引。
- 排除 `out.xvg` 的 `#`、`@` 注释及空行，按样本号回查实际数据行，取得时间、RMSD、Rg。确认样本号在范围内；不能用未核实的固定起点、20 ps 间隔或 +4000 等偏移换算。

先汇报“最低网格、相对自由能、全部候选样本号及真实时间”。用户只要求查找汇报时停在这里。最低箱含多帧时，通过中文选项框让用户选一帧或明确选择规则；已选时间不重复问。同一箱的帧不能靠该箱能量继续排序，也不能擅自挑第一帧。

## 2. 后台 VMD 与帧时间核对

用户已要求全部后台操作：使用现有 VMD 的原生文本模式，不弹 GUI、不操作前台会话，不关闭用户已打开的 VMD。原生命令保存在本次项目的 `.vmd` 执行记录中；不重写 FEL 算法，不修改用户的原 Bash/Python 脚本，也不声称它就是未提供的 `FEL.py` 或 `min_protein.tcl`。

VMD 命令结构，路径及 `F` 必须换成本次核实值：

```tcl
set mid [mol new {ABSOLUTE_MD_GRO} type gro waitfor all]
set structure_frames [molinfo $mid get numframes]
mol addfile {ABSOLUTE_MD_NOPBC_XTC} type xtc waitfor all molid $mid
set loaded_frames [molinfo $mid get numframes]
set F VERIFIED_VMD_FRAME
molinfo $mid set frame $F
set reported_time [molinfo $mid get physical_time frame $F]
```

Windows 启动示例：

```powershell
$vmdJob = Start-Process -FilePath $vmdExe -ArgumentList @('-dispdev','text','-e',$nativeCommandFile) -WorkingDirectory $outputDir -WindowStyle Hidden -RedirectStandardOutput $stdoutLog -RedirectStandardError $stderrLog -PassThru
```

`$vmdExe` 来自实际安装位置。等待要有时间上限；记录进程和输出，只管理本次自己启动的进程。命令文件用 `catch` 记录错误及 `status=PASSED/FAILED`，正常结束 `quit`；VMD 可能捕获错误后仍返回退出码 0，必须读取验证状态。

VMD 使用从 0 开始的帧编号，载入 GRO 本身可能贡献结构帧，必须读取实际帧数。保留一个 GRO 结构帧后追加完整 XTC，且 FEL 与 XTC 样本逐帧一一对应时，FEL 的 1 起样本号可直接对应 VMD 帧号。若 FEL 截过窗口、抽帧、跳帧，或 VMD 加载顺序不同，则按真实时间建立映射，不能套固定加减。不要为了数字一致删除结构帧、删首帧或重复追加轨迹。

部分 VMD/轨迹读取器可能不能返回有效的 `physical_time`。此时不能写入期望时间冒充验证，也不能仅按帧数猜测。可按实际时间用原生 GROMACS 生成内部核验坐标：

```text
gmx trjconv -s md.tpr -f md_noPBC.xtc -dump TIME_PS -o verification_TIMEps_fullsystem.gro
```

选择真实菜单中的 System（所有原子），检查日志实际 `Dumping frame at t=` 和输出 GRO 的时间。`-dump` 可能返回最近帧，必须确认实际时间就是选定时间。该全体系 GRO 仅为核验中间文件，不作为最终无溶剂 PDB 交付。

在 VMD 中加载核验 GRO，比较其原子数、顺序与选定帧坐标：

```tcl
set rid [mol new {ABSOLUTE_VERIFICATION_GRO} type gro waitfor all]
set frame_all [atomselect $mid all frame $F]
set reference_all [atomselect $rid all frame 0]
set coordinate_difference [measure rmsd $frame_all $reference_all]
```

比较不做拟合、不平移/旋转；先逐原子检查名称和残基顺序。允许误差由实际 XTC/GRO 坐标精度确定并记录单位 Å。时间或坐标不符时停止导出并解释原因，不放宽阈值掩盖帧映射错误。

## 3. 只导出完整蛋白和底物

本步骤已确认的交付范围为“蛋白＋底物、无溶剂和离子”。从本次 GROMACS 索引和拓扑识别目标，不能把 `MOL`、原子范围或残基数写成各种体系通用常量。多底物或特殊结合组分的取舍未明确时用中文选项确认。

- 将选定 GROMACS 组的 1 起原子编号映射到 VMD 0 起 atom index；这是原子索引映射，不是轨迹帧加减。只有已验证连续时才能缩写为 `index A to B`；非连续/多链用完整真实成员。
- 不单独依赖 VMD `protein` 关键字；非标准端基命名、修饰或未识别残基可能导致漏选。对照真实蛋白索引核对全长、各链和端基，不能为了通过检查把期望原子数改小。
- 排除所有实际溶剂/离子，不仅是 water；按当前拓扑识别有机溶剂和盐。必要辅因子/金属应按用户研究对象另行确认，不凭残基名猜测处理。
- 读取 `md_noPBC.xtc` 不自动保证非共价蛋白—底物处在同一周期镜像；先检查完整性和相对位置，需额外重组/居中时说明处理，保留原坐标并按选择执行。

使用 VMD 原生命令导出到新目录，已有文件不覆盖：

```tcl
set selected [atomselect $mid {VERIFIED_PROTEIN_AND_LIGAND_SELECTION} frame $F]
$selected writepdb {ABSOLUTE_NEW_OUTPUT_PDB}
```

按 [短文件名规则](project-layout.md)，蛋白＋底物的选定代表构象保存为 `FEL/complex.pdb`；仅酶的口袋计算输入保存为 `pocket/protein.pdb`。具体时间、候选样本和选区放入记录，既有时间后缀文件可保留在历史位置。多构象用简短子目录和映射区分，不能静默覆盖或将不同时间混为同一个结构。

写出后在 VMD 重新读取 PDB，核对总原子数、蛋白残基数、所有指定底物、末端残基、原子/残基顺序及无溶剂/离子；与选定帧直接比较坐标，不做拟合，误差限按 PDB 小数精度确定。原结构和轨迹哈希保持不变。

在 FEL 模块目录保存原生命令、stdout/stderr、核验记录和 `extraction.json`，包括最低箱、自由能、样本号、VMD 帧号、真实时间、GRO/XTC 加载顺序、选区、计数、坐标误差及输出路径/哈希。交付 PDB 和检查结论后停下；这不等于已经完成三维渲染、通道或口袋分析。

## 与下一步的连接

具体最低箱、候选帧、时间、原子数和验证误差仅保存在项目记录。用户要求通道分析时，将通过回读核验的 PDB 交给 [通道](channel.md)；该步骤重新确认起点、障碍组分及搜索参数，不把蛋白＋底物导出范围自动等同于通道几何计算范围。

原生命令参考：[VMD 文本模式与启动选项](https://www-s.ks.uiuc.edu/Research/vmd/current/ug/node246.html)、[VMD molinfo](https://www-s.ks.uiuc.edu/Research/vmd/current/ug/node142.html)。
