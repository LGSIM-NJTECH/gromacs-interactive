# 盐桥：VMD 计算、残基对占有率与 Origin 热图

同一个 skill 的分析模块，输出位于实际 `MD_ROOT/saltbridge`。以当前匹配的 `md.gro`、`md_noPBC.xtc` 和已核实拓扑为输入；项目数据、原子编号、残基与结果不写入 skill。

## 中文选择与化学定义

先明确酶内部的范围：单链内、整个多链酶（是否含链间）或指定区域。核对蛋白索引，排除底物、溶剂和离子；链、插入码、残基编号重复时建立唯一结构映射。随后询问有效时间区间、采样、距离判据、残基范围及图型/模板。用户已明确提供热图模板时不重复询问图型，已有适用选择沿用。

读取当前 VMD Salt Bridges 插件和实际 `acidic`/`basic` 宏。原生通常以酸性侧链 O 与碱性侧链 N 的任意原子距离在 3.2 Å 内找到候选残基对，可选额外侧链重原子质心距离过滤。VMD 单位 Å，与 GROMACS nm 相差十倍。不要增加氢键角度条件。

VMD 默认 acidic 为 ASP/GLU，basic 包含 ARG/LYS/HIS/HSP；名为 HIS 的中性组氨酸也可能被包括。展示“原生分类”与“按真实质子化/电荷筛选”选项。后者须从匹配拓扑核对各残基状态和原子电荷、结构及原子顺序，不能凭名称判断。ASP/GLU 的质子化型、中性 LYS、特殊残基和末端电荷分别核实；本模块侧链定义不自动包含末端盐桥。无拓扑或电荷不确定时说明缺口并请用户选择，不擅自给 HIS 带正电。

## VMD 原生流程

后台启动自有 VMD 文本模式，不影响已有可视化会话。加载匹配 GRO 与完整处理轨迹，读取真实结构帧数和 XTC 帧数；GRO 初始结构帧不进入轨迹占有率分母。按实际加载顺序映射帧，不固定写死加减一。时间来自已核验轨迹，不能将失效的 VMD `physical_time` 或虚构时间当实测；GROMACS 检查证明等间隔时可明确记录由起点、间隔和完整帧序列建立时间映射。

确认蛋白完整、链间周期镜像合适；VMD `measure contacts`/插件不自动处理周期镜像。`-pbc mol` 不保证多链复合物重组。需要额外重组时说明并保留原轨迹，不能以远离镜像的距离认定无盐桥。

原生命令形状：

```tcl
package require saltbr
set sel [atomselect $mid $verified_enzyme_selection]
::saltbr::saltbr -sel $sel -frames $verified_frame_range -ondist $chosen_cutoff_A -comdist none -upsel no -writefiles yes -outdir $native_directory -log saltbr.log
```

`-upsel no` 仅适合静态成员选区；动态空间选区逐帧更新。启用 COM 筛选会改变候选规则，需要单独适配和记录。本版 `scripts/vmd_saltbridge.tcl` 实现无额外 COM 限制、静态蛋白选区的路径；不能忽略用户选择的 COM 阈值。

脚本由项目命令文件设置 `structure`、`trajectory`、`output_dir`、`expected_atoms`、`protein_indices`、`acid_indices`、`base_indices`、`cutoff`、`times` 后 source；索引是 VMD 的 0 起原子编号，`times` 为按实际顺序的 XTC 帧时间 ps。酸/碱索引须是已核实完整残基成员且属于蛋白，两者不重叠。确认无旧输出再运行。必要时只在本次自有实例中按核实成员设定宏，不改 VMD 安装或用户全局配置。

脚本首先调用原生插件保留 `native/saltbr.log` 和逐对 `.dat`。随后仍在 VMD 中用同样酸性 O/碱性 N 选区执行逐帧 `measure contacts`，将同一残基对多个原子接触去重为 0/1；用 `measure bond` 保存该帧最近 O–N 距离辅助核验。逐帧并集必须与原生插件候选数量一致，多链时还要核对唯一映射和原生名称警告。保留 `pairs.tsv`、`frames.csv`、`vmd-check.txt`，读取 PASSED 状态，不仅看进程退出码。

**不要直接阈值化默认 `.dat` 计算占有率。** 插件该文件输出的是酸性 O 原子组中心与碱性 N 原子组中心之间的距离，与发现候选用的任意 O–N 接触判据不同。[VMD 官方说明](https://www.ks.uiuc.edu/Research/vmd/plugins/saltbr/)。

## 汇总规则与 CSV

每对残基占有率＝满足所选判据的采样帧数/分析的全部真实轨迹帧数，范围 0–1；所有分析帧计入分母，不只统计接触帧。多个原子配对、同一残基对多个接触都只记一次。缺失帧不是 0；不等间隔采样时明确是帧占比，如需时间加权另行设计。总数、逐帧数、逐对占有率和寿命是不同指标。

```text
python scripts/saltbridge_csv.py MD_ROOT/saltbridge --label SYSTEM_NAME
```

输入为原生计算已通过的上述文件，输出 `occupancy.csv`（形成帧数/分母/占有率）与 `saltbridge.csv`（第一列 `Salt bridge`，其后为当前体系的占有率）。单条轨迹不要写 WT mean/MUT mean 冒充重复均值。默认报告所有至少出现一次的合格残基对，并按占有率降序标明排序；需要阈值、指定对或截取前若干行时询问用户并保留完整表。

多体系比较须核实序列/链/结构映射，以对应位点组成共同残基对列表，不按文本编号或行号盲配。某对在另一轨迹从未接触，只有该对存在且全部帧均已计算才可填 0；位点不存在或映射不明确使用缺失标记并明确显示，不能补 0。平行先逐条算占有率，再按已确认规则汇总；相关帧不是独立重复。当前 helper 不自动完成 WT/MUT 映射或独立重复统计。

## Origin 热图

参考图在 `../assets/saltbridge-reference.png`，仅复用用户选定的浅色→青蓝色、矩形单元格边界及右侧色条，不复制参考数据、残基名或 WT/MUT 标签。单体系一列，多体系/独立重复按实际来源形成多列；纵轴残基对，横轴体系名，色标 Occupancy（0–1），不插值或平滑。文字与背景必须可读。色标固定 0–1 便于比较，不逐列归一化。

先以普通 Python 执行 `scripts/origin_saltbridge.py JOB.json --check-only`，随后用 `scripts/run_origin_csv.ps1 -Job ABSOLUTE_JOB_JSON -WorkerName origin_saltbridge.py` 在独立 Origin 实例中执行热图 worker。JOB 包括真实 `csv`、`csv_sha256`、`output_dir`、`stem: saltbridge`、`chart: heatmap`、两个已确认布尔字段 `chart_confirmed`/`template_confirmed`、`smooth: false`、`color_range: [0,1]`。不得将此 JSON 当作未经回答的用户选择。

该 worker 保留与 CSV 对应的原生工作表和轴标签表，经 `MSheet.obj.MatrixObjects(0).SetData/GetData` 读写同尺寸矩阵，再用 `Heat_Map` 模板、原生图型 105 绘图，单列保持一列。此路径不要求 Origin 内置 Python 安装 NumPy。用 `Layer.CMap` 设置色标，以 `draw -n ... -l {X1,Y1,X2,Y2}` 添加可编辑单元格边界；用实际轴的 `label.type=2` 与 `label.dataset$` 绑定标签数据（核对顶部/底部轴），工程重开后核对类型与数据集。保存 `saltbridge.opju` 与 `saltbridge.png`，不嵌入位图代替热图。原生接口依据：[Origin 热图示例](https://docs.originlab.com/python/examples/graphing/)、[Layer.Axis.Label](https://docs.originlab.com/labtalk/ref/layer-axis-label-obj/)、[draw](https://docs.originlab.com/labtalk/ref/draw-cmd/)。

当前 worker 支持完整有限占有率矩阵，不自动处理缺失值、位点映射或重复均值。用户要求这些模式时先适配并独立核验；不能补零或复制一列制造第二体系。

工程重开后核对 CSV 标签、每个占有率、源数据绑定、行顺序/方向、真实列数、色标范围与配色。查看 PNG，确认无截字、缺行、倒序或多余体系列。零候选盐桥时交付原始日志与空结果说明，不伪造热图值。项目内保存配置、输入输出哈希、判据、拓扑状态、帧映射和验收记录。短轨迹占有率不单独证明长期稳定性或结合自由能。
