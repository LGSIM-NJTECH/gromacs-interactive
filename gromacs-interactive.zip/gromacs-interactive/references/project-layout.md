# MD 总目录下按分析模块保存结果

同一个 gromacs-interactive skill 包含多个分析模块，项目输出按模块分文件夹，不拆成多个技能安装包。先找到当前实际产生匹配 `md.tpr`、`md.gro`、`md.xtc` 的目录，将其记为 `MD_ROOT`；不要把别的体系目录、技能安装目录或历史验证目录当作项目根目录。

用户要求的结构与短名称：

```text
MD_ROOT/
  md.tpr
  md.gro
  md.xtc
  rmsd-Rg-RMSF/
    md_noPBC.xtc
    rmsd.xvg / rmsd.csv / rmsd.opju / rmsd.png
    rmsf_<时长>ns.xvg / .csv / .opju / .png
    rg.xvg / rg.csv / rg.opju / rg.png
    record.json
  FEL/
    rmsd-fel.xvg
    rg-fel.xvg
    out.xvg
    gibbs.xpm / gibbs.log / gibbs.xyz / gibbs.csv
    bindex.ndx
    gibbs.opju / gibbs.png
    complex.pdb
    extraction.json
    record.json
  tunnel/
    complex.pdb
    channel.pdb / channel.r
    metrics.csv / profile.csv / residues.txt
    channel.pse / channel.png
    record.json
  pocket/
    protein.pdb
    protein_out/
    pockets.csv
    pocket.pse / pocket.png
    record.json
  hbond/
    hbond_index.ndx
    hbnum.xvg / hbnum.csv / hbnum.opju / hbnum.png
    summary.csv
    record.json
  saltbridge/
    native/
    pairs.tsv / frames.csv / occupancy.csv
    saltbridge.csv / saltbridge.opju / saltbridge.png
    record.json
  dssp/
    dssp2gp.bsh
    dssp.dat / dssp.gp / dssp~count.gp
    ss.png
    record.json
  DCCM/
    DCCM.ipynb
    eigenvalues.xvg / eigenvectors.trr
    results.xpm / results.dat
    results.csv / results.jpeg
    residues.csv
    record.json
```

此结构是启用模块后的输出约定，不是预先制造所有结果的清单。只创建当前需要或用户要求整理的目录，尚未计算的文件不占位、不伪造。RMSF 时长按实际区间生成；已指定的 `md_noPBC.xtc`、`rmsd.xvg`、`rg.xvg` 和 FEL 原命令名称继续保留。

“选取能量最低点”属于 FEL 后处理，蛋白＋底物代表构象使用简短的 `FEL/complex.pdb`，仅蛋白分析输入使用 `pocket/protein.pdb`。具体时间、候选帧、选区和原子数写入 `extraction.json`/`record.json`，不再叠入很长的文件名。文件实际内容与名称一致，不能让 protein.pdb 含底物或把不同选帧静默混用。

制图的 PNG、CSV、OPJU/PSE 与对应分析放在同一模块目录，不再为一次初稿层层增加 `analysis/xxx-validation/retry-xx/results/selected-xxx/origin-final` 等包装目录。必要的日志和执行记录使用 `run.log`、`run.py`、`run.sh`、`plot.json`、`record.json` 等短名称；同模块多指标可用 `rmsd.json`、`rg.json` 等区分。

fpocket 的 `protein_out` 及各口袋原生命名、CAVER 原始压缩包内部层级等软件原生输出保留，不能为缩短名字破坏引用或丢弃数据。简名交付副本须记录原生编号/名称映射和哈希，不能仅因都叫 channel.pdb 或 pocket.png 就跨体系复用。多通道/多口袋可用 `channel1`、`channel2` 或 `pocket1`、`pocket2`，其编号必须来自实际选择；不强制每个体系都生成同样数量。

已有同名文件先检查来源和哈希，一致时可复用，不重复运行追加式脚本。已获授权的重跑需要替换不同内容时，先将旧输出备份到模块内简短的 `previous/1` 等位置并保留映射，再执行；不能静默覆盖。不同体系各有自己的 MD_ROOT；平行或不同窗口的多次分析可在模块内用简短、有说明的子目录区分，避免靠长文件名编码所有信息。

整理历史结果时优先将已核验的最终文件复制到上述模块目录并核对哈希，原始记录可继续保留追溯。不要未经要求递归移动/删除整个 MD 目录，也不要因改了目录结构而重跑模拟。将旧路径到新路径映射保存在项目 record.json，技能只保存本方法。

远程服务器工作目录以用户指定位置为准，可在其下建立同名模块目录。核实共享路径到服务器实际文件系统的映射后再运行程序，UNC 可访问只证明文件共享可用，不证明 SSH 登录或软件已执行。上传前后核对输入哈希，回收结果核对实际输出；服务器结果和本地 MD_ROOT 对应关系写入项目记录。
