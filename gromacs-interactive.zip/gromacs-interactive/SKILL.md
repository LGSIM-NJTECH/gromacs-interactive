---
name: gromacs-interactive
description: 通过中文选项和数值输入交互执行 GROMACS 体系准备、拓扑维护、模拟、排错及轨迹分析。适用于用户提供初始结构、参数或已有模拟文件并希望实际操作的任务。
---

# 中文交互 GROMACS 助手

## 行为约定

这是由 Codex 驱动的交互技能，依赖可调用的 GROMACS 和文件工具；不是独立 GUI 或无人值守模拟程序。通过宿主的用户输入工具显示中文选择框和自由文本数值输入，不自行创建系统弹窗。工具不可用时在聊天中列出选项并等待回答。

输入是用户指定目录及研究目的。先确认当前授权阶段；要求逐步实践时一次完成一阶段。不能把另一目录的历史轨迹审计当成本次初始体系构建。开发或检查技能不等于授权启动实际模拟。

每次使用说明正在使用本技能。保留项目已有的命名和布局，在其可写范围保存命令、版本、选择、结果和修复记录。原始输入保持可恢复；TOP/MDP 修改先备份。项目数据与技能安装目录分离。

技能只保存通用方法、命令模板、交互规则和用户提供的原始脚本/样式模板。验证数据、项目绝对路径、作业编号、固定帧号和结果表保存在对应项目，不写入技能作为案例或默认参数。每个新体系重新识别输入、适用条件与参数；复用的是方法，不是上一体系的选择和结果。

输出位置遵循 [项目目录与短文件名](references/project-layout.md)：以实际 MD 文件目录为总目录，分析模块分别使用 `rmsd-Rg-RMSF`、`FEL`、`tunnel`、`pocket` 等子文件夹。制图和验证文件保存在对应模块内，不再层层创建长名称的验证目录；软件原生输出层级保留。已明确的指标文件名继续沿用，具体帧时间和选择放入项目记录。

## 所有未确定的选项由用户选择

1. 读取实际程序菜单/输入文件，保留英文名称、实际编号和必要的中文解释。不能硬编码力场、水模型或索引组编号。
2. 用 `request_user_input_async`（或当前宿主等价工具）显示中文选项；数值使用不设 options 的自由输入问题。可提供推荐与原因，但不得预选后当作已获回答。
3. 等待用户实际提交再执行依赖步骤。等待时只做独立检查；无回复、超时、工具失败都不是选择。用户明确说取消立即停止。
4. 已明确选择并记录的设置沿用；菜单/输入条件变化时核对适用性，不重复询问已确定事项。
5. 交互程序用持久终端运行：读取当前提示，暂停，提问，收到答案后只输入当前问题所需的一次回答。没有持久终端能力时，先从安装目录/版本帮助查明选项，再提问，使用明确名称的非交互参数；不要为取得菜单启动重复作业。

在项目记录里保存每次问题原文、实际菜单/版本、用户答案、对应名称/数值/单位与执行状态；用户答案到达后先核对对应的问题，不能将另一个问题的回复用于当前菜单。

### 数量输入

添加每种溶剂、水或离子前询问用户；不得写死分子数、配比、盐浓度或自动填满。

- 水：选择指定最终分子数、额外添加分子数或自动填满；明确 `-maxsol` 是上限而非保证精确加入。
- 混合溶剂：输入各组分数量，或明确配比与总量；含水量说明质量/摩尔分数的基准。
- 离子：选择仅中和、指定最终数量、额外数量或目标浓度；说明 genion 通常替换选定溶剂，记录被移除的组分数量。
- 数量为非负整数，浓度/比例为有单位的合理数值；模糊、负值、配比无法整数化时让用户澄清。
- 中和所需离子由核实的拓扑电荷计算并展示，等用户选择；不能凭 GRO/PDB 或名称推断电荷。
- 实际加入不足时不擅自改变数量、盒子或重叠阈值。报告实加数、原因、选项并等待选择。

## 路由

- 初始文件、建模和模拟：读 [references/simulation.md](references/simulation.md)。
- TOP 计数同步：读 [references/topology.md](references/topology.md)，用 `scripts/gmx_files.py` 先生成建议和差异，再应用并检查。
- 诊断与修复：读 [references/troubleshooting.md](references/troubleshooting.md)。
- 已完成模拟的分析和作图：读 [references/analysis.md](references/analysis.md)。按用户授权逐项执行 [轨迹 PBC 预处理](references/analysis-pbc.md)、[骨架 RMSD](references/analysis-rmsd.md)、[逐残基 RMSF](references/analysis-rmsf.md)、[骨架 Rg](references/analysis-rg.md) 和 [CSV→Origin 绘图](references/origin-csv.md)，不批量启用其他指标。每次出图先询问图型、沿用/自定义模板及平滑设置，已经明确的回答沿用。
- FEL 自由能景观、SHAM、XPM 或低自由能构象：读 [references/analysis-fel.md](references/analysis-fel.md) 中的方法、完整命令顺序及排错入口；Origin 的填色、导出和工程回读命令见 [references/fel-origin-native.md](references/fel-origin-native.md)，原 PPT/脚本逐页解读见 [references/fel-source-review.md](references/fel-source-review.md)。蛋白体系按已确认的骨架 RMSD–Rg 定义逐步进行；其他研究对象先确认坐标定义，不能仅改标签。确认区间、温度、网格、图型及代表构象规则。
- **选取能量最低点**：读 [references/energy-minimum.md](references/energy-minimum.md)。从本次 gibbs.log→bindex.ndx→out.xvg 汇报最低箱及候选时间，用户选帧后用后台 VMD 读取 md.gro＋md_noPBC.xtc，核验实际时间，导出仅含完整蛋白和底物的 PDB。沿用已确定的选择，不把其他目录或体系混入本次查找。
- **通道**：读 [references/channel.md](references/channel.md)。将用户选定的代表构象送入 CaverWeb，确认起点、参与计算的组分与搜索参数；结果完成后展示实际通道供用户选择，下载并核验原生通道文件。**通道模块内部自动衔接 PyMOL 绘图**：选定通道且原生文件核验通过后，按 [PyMOL 方法](references/channel-pymol.md) 调用随包 `scripts/render_channel.py`，默认沿用已确认的白底、蓝色全酶、浅灰透明表面、黄色通道和橙色底物样式，不再等待用户另说“继续画图”。生成 `tunnel/channel.png`、`channel.pse`，回读会话并检查图片后才报告通道模块全部完成；用户提出新参考图时再更新样式。WT/MUT 按对应出口、衬里残基和几何匹配，不按编号配对。
- **口袋（fpocket）**：读 [references/pocket.md](references/pocket.md)。从选定代表构象提取纯酶 `pocket/protein.pdb`，核实服务器执行连接及已安装版本，让用户选择默认/自定义参数；运行后同步并核验原生结果。弹出活性口袋/催化关键残基输入，核对真实位点并比较各口袋，按用户选择或明确委托筛选。需要时用 VMD 原生导出 `pocket.pdb`，再用 PyMOL 绘制全酶＋口袋并回读可编辑会话。文件上传成功不等于软件已运行，各分支据实际输出验收。
- **氢键**：读 [references/analysis-hbond.md](references/analysis-hbond.md)。建组前弹出酶与底物、活性位点与突变位点或自定义选区，让用户选择；按真实版本确认氢键判据，保留 `hbond_index.ndx`、`hbnum.xvg`。逐帧计数整理为两列 `hbnum.csv`，按用户图型和模板用原生 Origin 生成可编辑工程及图片，核对原始值和整数刻度。只接入当前授权分析，不自动扩大为逐键寿命/占有率。
- **盐桥**：读 [references/analysis-saltbridge.md](references/analysis-saltbridge.md)。按真实电荷与用户选择确定酶内酸/碱残基，用 VMD 原生插件识别候选并逐帧按一致的 O–N 判据统计残基对占有率；整理 CSV，在 Origin 绘制单体系或经核实映射的多体系热图。默认距离输出不直接当作最近原子距离，原始帧与结构帧分开计数。
- **DSSP 二级结构**：读 [references/analysis-dssp.md](references/analysis-dssp.md)。按用户的 `gmx dssp → bash dssp2gp.bsh → gnuplot dssp.gp` 流程，使用随 skill 附带的原始 `assets/dssp-originals/dssp2gp.bsh`。在当前电脑/服务器检测 GROMACS 版本、Bash/awk 和 gnuplot，不绑定脚本来源服务器。中文确认选区、区间与图型，按实际帧时间显式设置转换参数，检查残基/断点映射和原生图片；旧版 do_dssp 分支单独确认，不改名冒充新版 DAT。
- **DCCM 动态交叉相关**：读 [references/analysis-dccm.md](references/analysis-dccm.md)。保留用户 `gmx covar` 的输出文件名和随包原 notebook 代码；按真实菜单确认两次拟合/分析选区，不固定 `3 3`。按用户要求完全沿用原 notebook 的九项求和与归一化算法，不再强制选择其他公式或添加标准分支；路径适配只改项目副本，不绑定来源电脑。核对矩阵格式、残基映射和原脚本图像。

## 配套脚本

基础文件工具使用可运行的 Python 3 标准库，不修改用户默认 Python。通道内的 `scripts/render_channel.py` 使用当前电脑已安装 PyMOL 的 Python 环境（`pymol2`、NumPy）；检测实际位置，不写死安装路径，不把科学软件本体打包进技能。

```text
python scripts/gmx_files.py inspect --directory PROJECT
python scripts/gmx_files.py top-propose --top PROJECT/topol.top --gro PROJECT/actual.gro --mapping PROJECT/molecule-map.json --proposal PROJECT/top-change.json
python scripts/gmx_files.py top-apply --proposal PROJECT/top-change.json
```

脚本 inspect 只读本目录的结构、MDP、ITP/TOP，报告清单和基础不一致；不证明化学结构/力场正确。TOP 工具只处理简单、无条件、位于文件末尾的单个 `[ molecules ]` 段，通过各分子模板逐原子匹配坐标来获得数量与顺序。其余情况由代理结合拓扑含义处理，不能盲目套用脚本。

当前自动化范围：基础输入检查、TOP 计数建议/差异/备份应用、`scripts/observable_csv.py` 的 RMSD/RMSF/Rg XVG→CSV 导出、`scripts/hbond_csv.py` 的逐帧氢键计数导出，以及 CSV 核验、原生 Origin 绘图与工程回读；通道模块内另含 `scripts/render_channel.py` 的后台 PyMOL 渲染、PSE 回读及坐标/半径核验。GROMACS 分析计算由代理按单项说明调用；新数据、误差带和新模板按其实际输出核验。具体运行记录保存在项目中，不声称已针对所有体系验证全自动流程。

FEL 计算/转换继续只用用户提供的 `assets/fel-originals/xpm2all-2.bsh`、`xpm2png.py` 及 PPT 的 GROMACS/Excel/Origin 流程，不新增替代 FEL 算法。原件保持不变；原脚本报错说明原因和解决选项后按用户选择处理。“选取能量最低点”采用用户另行指定的后台 VMD 原生导出，无需等待未提供的 FEL.py/min_protein.tcl；若用户指定执行这两个历史脚本，仍需其完整原件，不按截图补造。二维 Origin、三维曲面、原 Python PNG、历史构象脚本及通道比较分别核验，不把一个分支的成功推广到其他分支。

## 通用性与判断边界

不固定蛋白、配体、残基、力场、温度、盒子或模拟长度。先识别单蛋白、蛋白小分子、多链、膜、核酸、混合溶剂及特殊化学组分，再采用适用流程。

标准蛋白的 `pdb2gmx` 不自动参数化任意配体、金属中心、共价配体或修饰残基。不能把忽略未识别组分、`-missing`、放宽警告作为自动解决办法。特殊体系所需模型/参数不足时明确说明缺口并提出选项。

每次结束说明完成阶段、真实验证结果、未解决项和下一步选择。区分生成文件、程序运行成功、科学条件满足；不能只按退出码认定模拟可信。
